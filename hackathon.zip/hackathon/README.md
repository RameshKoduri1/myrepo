# The Product

We are building a platform to provide users with real time data monitoring dashboards for their public and private cloud infrastructure.

# Tech Stack

Frontend: React JS - Single Page Application that will fetch data from restful backend services. See the reactapp folders in this repo.

Backend: PHP, Ruby on Rails, GO and others - Our backend is written as a bunch of restful services. We have a distributed development team with team members specializing in different languages / frameworks. We support a bunch of frameworks as long as the developers stick to certain RESTFUL API specifications to bring standardization to the platform. 

Databases: Postgres

Other services: Elasticsearch, Real time streaming with Kafka and AWS Kinesis, others ..

Development and Deployments: Everything is containerized. Local development is all docker based. See the docker folder in the repo. Production runs on Kubernetes.

# How to run this project locally

```
cd docker

docker-compose -f docker-compose-appstack.yml up --build
```

# Project Management

We use the GITHUB issue tracker on this project to track bugs / features