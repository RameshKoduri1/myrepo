import React from "react";

import box_image from "../../../assets/images/box_image.jpg";
import banner_logo from "../../../assets/images/banner-logo.jpg";
import table_logo_1 from "../../../assets/images/table-logo-1.jpg";
import table_logo_2 from "../../../assets/images/table-logo-2.jpg";
import box_center from "../../../assets/images/box-center.jpg";
import box_banner from "../../../assets/images/box-banner.jpg";

const HomeBody = props => {
  return (
    <div>
      <section className="home-text-top p-3 bg-white fixed-top card desktop-view">
        <h4 className="mb-0">
          Discover innovative companies and the people behind them.
        </h4>
      </section>
      <div className="container-fluid">
        <div className="row mt-2">
          <div className="col-md-6 col-sm-12 mt-3">
            <div className="row">
              <div className="col-12 mb-3">
                <div className="card">
                  <h3 className="card-header">
                    <i className="fas fa-building mr-2" />Latest insights and
                    analysis
                  </h3>
                  <div className="card-body pb-1 ">
                    <div className="row mb-3 news-box">
                      <div className="col-md-3 col-sm-3 pr-0">
                        <a
                          href="#"
                          className="new-img"
                          style={{ backgroundImage: `url(${box_image})` }}
                        />
                      </div>
                      <div className="col-md-9 col-sm-9 ">
                        <a href="#">
                          <h6 className="card-subtitle mb-1 text-muted date">
                            May 1 2018
                          </h6>
                          <h4 className="card-title font-weight-bold mb-2">
                            Penetrate your existing market.
                          </h4>
                          <h6 className="card-subtitle mb-1 text-muted">
                            Jason D. Rowley{" "}
                          </h6>
                          <p className="mb-0">
                            {" "}
                            When you think about how to grow your business, the
                            first thing that probably comes to mind is getting
                            new customers. But the customers you already have
                            are your best bet for increasing your sales; it’s
                            easier and more cost-effective to get people who are
                            already buying from you to buy more than to find new
                            customers and persuade them to buy from you. See 6
                            Sure Ways to Increase Sales and 10 Low-Cost Ways to
                            Promote Your Business for more.
                          </p>
                        </a>
                        <a href="#" className="card-link font-weight-bold">
                          Continue Reading
                        </a>
                      </div>
                    </div>

                    <div className="row mb-3 news-box">
                      <div className="col-md-3 col-sm-3 pr-0">
                        <a
                          href="#"
                          className="new-img"
                          style={{ backgroundImage: `url(${box_image})` }}
                        />
                      </div>
                      <div className="col-md-9 col-sm-9">
                        <a href="#">
                          <h6 className="card-subtitle mb-1 text-muted date">
                            May 1 2018
                          </h6>
                          <h4 className="card-title font-weight-bold mb-2">
                            Rolando, a business growth strategist
                          </h4>
                          <h6 className="card-subtitle mb-1 text-muted">
                            Jason D. Rowley{" "}
                          </h6>
                          <p className="mb-0">
                            {" "}
                            Rolando, who builds and scales seven, eight and
                            nine-figure businesses tells me that there are loads
                            of ways to grow a business quickly. But, only 15
                            core strategies that will truly make a real impact
                            on your bottom line. Some are time intensive at the
                            outset. That much should be expected. But, the
                            benefits and profits will ultimately make them well
                            worthwhile.
                          </p>
                        </a>
                        <a href="#" className="card-link font-weight-bold">
                          Continue Reading
                        </a>
                      </div>
                    </div>
                  </div>
                  <div className="card-footer text-center font-weight-bold">
                    <a href="#">SHOW ALL FUNDING ROUNDS ></a>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card p-0 bg-info text-white logo-banner">
                  <div className="row">
                    <div className="col-md-3 col-sm-3 col-xs-3 pr-0">
                      <img
                        className="card-img-top"
                        src={banner_logo}
                        alt="card-img-top"
                      />
                    </div>
                    <div className="col-md-9 col-sm-9 col-xs-9 pl-0">
                      <div className="card-body pt-3 pb-3">
                        <p className="card-text mb-2">
                          Add new data to Hackthon with Marketplace The Hackthon
                          app store: your one-stop shop for company data.
                        </p>
                        <a
                          href="#"
                          className="card-link text-uppercase text-warning"
                        >
                          GET STARTED
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card ">
                  <h3 className="card-header">
                    <i className="fas fa-dollar-sign mr-2 text-success" />Featured
                    Funding Rounds
                  </h3>
                  <div className="card-body p-0 ">
                    <div className="table-responsive">
                      <table className="table table-sm funding-table m-0">
                        <thead>
                          <tr>
                            <th>Organization Name</th>
                            <th>Transaction Name</th>
                            <th>
                              <span className="td-price mr-2">Money</span>
                              <span className="td-name">
                                Raised Lead Investors
                              </span>
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td scope="row">
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td>
                              <span className="td-price mr-2">$31M</span>
                              <a href="#" className="td-name">
                                <span className="font-weight-bold">
                                  Riverside Company{" "}
                                </span>
                              </a>
                            </td>
                          </tr>
                          <tr>
                            <td scope="row">
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td>
                              <span className="td-price mr-2">$31M</span>
                              <a href="#" className="td-name">
                                <span className="font-weight-bold">
                                  Riverside Company{" "}
                                </span>
                              </a>
                            </td>
                          </tr>
                          <tr>
                            <td scope="row">
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td>
                              <span className="td-price mr-2">$31M</span>
                              <a href="#" className="td-name">
                                <span className="font-weight-bold">
                                  Riverside Company{" "}
                                </span>
                              </a>
                            </td>
                          </tr>
                          <tr>
                            <td scope="row">
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td>
                              <span className="td-price mr-2">$31M</span>
                              <a href="#" className="td-name">
                                <span className="font-weight-bold">
                                  Riverside Company{" "}
                                </span>
                              </a>
                            </td>
                          </tr>
                          <tr>
                            <td scope="row">
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_1} alt="table-logo-1" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td>
                              <span className="td-price mr-2">$31M</span>
                              <a href="#" className="td-name">
                                <span className="font-weight-bold">
                                  Riverside Company{" "}
                                </span>
                              </a>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="card-footer text-center font-weight-bold">
                    <a href="#">MORE Hackthon NEWS ></a>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card p-0">
                  <div className="row">
                    <div className="col-md-6 col-sm-6 col-xs-6 pr-0">
                      <img
                        className="card-img-top"
                        src={box_center}
                        alt="card-img-top"
                      />
                    </div>
                    <div className="col-md-6 col-sm-6 col-xs-6 pl-0">
                      <div className="card-body">
                        <h5 className="card-title"> Hackthon work for you</h5>
                        <p className="card-text">
                          Find and monitor the right companies with Hackthon.
                          Get unlimited search filters, API tools, and
                          Excel exports.
                        </p>
                        <button
                          type="button"
                          className="btn btn-raised btn-success"
                        >
                          Start Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-6 col-sm-12 mt-3">
            <div className="row">
              <div className="col-12 mb-3">
                <div className="card">
                  <h3 className="card-header">
                    <i className="fas fa-building mr-2 text-info" />Activity
                    this week
                  </h3>
                  <div className="card-body pt-1 pb-1">
                    <div className="row">
                      <div className="col-md-6 col-sm-6 col-12 p-2">
                        <div className="card small-widget text-center p-2">
                          <h5 className="card-title mb-0 font-weight-bold text-info">
                            373
                          </h5>
                          <p className="card-text">
                            <i className="fas fa-dollar-sign mr-1 text-success" />Funding
                            rounds announced
                          </p>
                        </div>
                      </div>

                      <div className="col-md-6 col-sm-6 col-12 p-2">
                        <div className="card small-widget text-center p-2">
                          <h5 className="card-title mb-0 font-weight-bold text-info">
                            9.7B
                          </h5>
                          <p className="card-text">
                            <i className="fas fa-dollar-sign mr-1 text-success" />Total
                            Fundings
                          </p>
                        </div>
                      </div>
                      <div className="col-md-6 col-sm-6 col-12 p-2">
                        <div className="card small-widget text-center p-2">
                          <h5 className="card-title mb-0 font-weight-bold text-info">
                            112
                          </h5>
                          <p className="card-text">
                            <i className="fab fa-slack-hash text-info mr-1" />Acquisitions
                            recorded
                          </p>
                        </div>
                      </div>
                      <div className="col-md-6 col-sm-6 col-12 p-2">
                        <div className="card small-widget text-center p-2">
                          <h5 className="card-title mb-0 font-weight-bold text-info">
                            22.7B
                          </h5>
                          <p className="card-text">
                            <i className="fab fa-slack-hash text-info mr-1" />Total
                            Acquisitions Amount
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card">
                  <img
                    className="card-img-top"
                    src={box_banner}
                    alt="card-img-top"
                  />
                  <div className="card-body">
                    <h5 className="card-title">
                      Introducing Hackthon Marketplace
                    </h5>
                    <p className="card-text">
                      Add best-in-class data to Hackthon—a la carte. From tech
                      stack to web traffic, Marketplace apps enhance your
                      Hackthon research to uncover the best prospect or investor
                      for you.
                    </p>
                    <button
                      type="button"
                      className="btn btn-raised btn-success"
                    >
                      Lets Go
                    </button>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card">
                  <h3 className="card-header">
                    <i className="fas fa-star mr-2 text-warning " />Featured
                    searches and lists
                  </h3>
                  <div className="card-body p-0">
                    <div className="table-responsive">
                      <table className="table list-table m-0">
                        <thead>
                          <tr>
                            <th className="pl-3 p-1">Name</th>
                            <th className="text-right pr-3 p-1">Entries</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td className="pl-3 font-weight-bold">
                              <a href="#">
                                San Francisco Tech Crawl 2018 Companies
                              </a>
                            </td>
                            <td className="text-right pr-3">35</td>
                          </tr>
                          <tr>
                            <td className="pl-3 font-weight-bold">
                              <a href="#">
                                San Francisco Tech Crawl 2018 Companies
                              </a>
                            </td>
                            <td className="text-right pr-3">35</td>
                          </tr>
                          <tr>
                            <td className="pl-3 font-weight-bold">
                              <a href="#">
                                San Francisco Tech Crawl 2018 Companies
                              </a>
                            </td>
                            <td className="text-right pr-3">35</td>
                          </tr>
                          <tr>
                            <td className="pl-3 font-weight-bold">
                              <a href="#">
                                San Francisco Tech Crawl 2018 Companies
                              </a>
                            </td>
                            <td className="text-right pr-3">35</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="card-footer text-center font-weight-bold">
                    <a href="#">ALL FEATURED SEARCHES AND LISTS ></a>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card ">
                  <h3 className="card-header">
                    <i className="fas fa-dollar-sign mr-2 text-success" />Trending
                    profiles
                  </h3>
                  <div className="card-body ">
                    <div
                      className="w-100 pr-3 pl-3 pt-1 pb-1 mb-1"
                      style={{ backgroundColor: "#0d47a1" }}
                    >
                      <a href="#" className="text-white">
                        At vero eos et accusamus
                      </a>
                    </div>
                    <div
                      className="w-75 pr-3 pl-3 pt-1 pb-1 mb-1"
                      style={{ backgroundColor: "#1976d2" }}
                    >
                      <a href="#" className="text-white">
                        At vero eos et accusamus
                      </a>
                    </div>
                    <div
                      className="w-100 pr-3 pl-3 pt-1 pb-1 mb-1"
                      style={{ backgroundColor: "#0288d1" }}
                    >
                      <a href="#" className="text-white">
                        At vero eos et accusamus
                      </a>
                    </div>
                    <div
                      className="w-50 pr-3 pl-3 pt-1 pb-1 mb-1"
                      style={{ backgroundColor: "#0288d1" }}
                    >
                      <a href="#" className="text-white">
                        At vero eos et accusamus
                      </a>
                    </div>
                    <div
                      className="w-50 pr-3 pl-3 pt-1 pb-1 mb-1"
                      style={{ backgroundColor: "#0288d1" }}
                    >
                      <a href="#" className="text-white">
                        At vero eos et accusamus
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card ">
                  <h3 className="card-header">
                    <i className="fas fa-dollar-sign mr-2 text-success" />Upcoming
                    Events
                  </h3>
                  <div className="card-body p-0 ">
                    <div className="table-responsive">
                      <table className="table table-sm acquired-table m-0">
                        <thead>
                          <tr>
                            <th className="pl-3">Start Date</th>
                            <th>Event Name</th>
                            <th className="pr-3">Location</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td className="pl-3">May 3, 2018</td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td className="font-weight-bold">
                              <a href="#"> Sofia, Sofia, Sofia, Sofia</a>
                            </td>
                          </tr>
                          <tr>
                            <td className="pl-3">May 3, 2018</td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td className="font-weight-bold">
                              <a href="#"> Sofia, Sofia, Sofia, Sofia</a>
                            </td>
                          </tr>
                          <tr>
                            <td className="pl-3">May 3, 2018</td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td className="font-weight-bold">
                              <a href="#"> Sofia, Sofia, Sofia, Sofia</a>
                            </td>
                          </tr>
                          <tr>
                            <td className="pl-3">May 3, 2018</td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td className="font-weight-bold">
                              <a href="#"> Sofia, Sofia, Sofia, Sofia</a>
                            </td>
                          </tr>
                          <tr>
                            <td className="pl-3">May 3, 2018</td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td className="font-weight-bold">
                              <a href="#"> Sofia, Sofia, Sofia, Sofia</a>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="card-footer text-center font-weight-bold">
                    <a href="#">Show All Event ></a>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card p-0 bg-info text-white logo-banner">
                  <div className="row">
                    <div className="col-md-3 col-sm-3 col-xs-3 pr-0">
                      <img
                        className="card-img-top"
                        src={banner_logo}
                        alt="card-img-top"
                      />
                    </div>
                    <div className="col-md-9 col-sm-9 col-xs-9 pl-0">
                      <div className="card-body pt-3 pb-3">
                        <p className="card-text mb-2">
                          Add new data to Hackthon with Marketplace The Hackthon
                          app store: your one-stop shop for company data.
                        </p>
                        <a
                          href="#"
                          className="card-link text-uppercase text-warning"
                        >
                          GET STARTED
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-12 mb-3">
                <div className="card ">
                  <h3 className="card-header">
                    <i className="fas fa-dollar-sign mr-2 text-success" />Featured
                    Acquisitions
                  </h3>
                  <div className="card-body p-0 ">
                    <div className="table-responsive">
                      <table className="table table-sm acquired-table m-0">
                        <thead>
                          <tr>
                            <th className="pl-3">Acquired Organization Name</th>
                            <th>Acquired Transaction Name</th>
                            <th className="pr-3 text-right">Price</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td className="pl-3">
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td className="text-right pr-3">$31M</td>
                          </tr>
                          <tr>
                            <td className="pl-3">
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td className="text-right pr-3">$31M</td>
                          </tr>
                          <tr>
                            <td className="pl-3">
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td className="text-right pr-3">$31M</td>
                          </tr>
                          <tr>
                            <td className="pl-3">
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">Soothe</span>
                              </a>
                            </td>
                            <td>
                              <a href="#">
                                <img src={table_logo_2} alt="table-logo-2" />
                                <span className="font-weight-bold">
                                  Series C - Soothe{" "}
                                </span>
                              </a>
                            </td>
                            <td className="text-right pr-3">$31M</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="card-footer text-center font-weight-bold">
                    <a href="#">MORE Featured Acquisitions ></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default HomeBody;
