import React from "react";
import SideBar from "../SideBar";
import Footer from "../Footer";
import HomeBody from "./HomeBody";

const Home = props => {
  return (
    <main className="home-wrapper">
      <SideBar />
      <div className="bmd-layout-backdrop" />
      <div className="home-inner-wrapper">
        <section className="home-widget-outer">
          <HomeBody />
          <Footer />
        </section>
      </div>
    </main>
  );
};
export default Home;
