import React, { Component } from "react";
import { Link } from "react-router-dom";
import single_news from "../../../assets/images/single-news.png";
import author_avatar from "../../../assets/images/author__avatar.png";
import NewsFooter from "./NewFooter";

class NewsDetails extends Component {
  render() {
    return (
      <main className="page-wrapper">
        <div className="container news-container">
          <section>
            <div className="row">
              <div className="col-xl-12">
                <h2 className=" text-center mt-3 mb-3 font-weight-bold">
                  Hackthon <a href="#">News</a>
                </h2>
              </div>
              <div className="col-xl-12">
                <a
                  href="#"
                  className="news-banner d-flex align-items-center"
                  style={{ backgroundImage: `url(${single_news})` }}
                >
                  <h1 className="text-center p-4">
                  Here Is Where CEOs Of Heavily Funded Startups Went To School
                  </h1>
                </a>
              </div>
            </div>
          </section>
          <section className="news-section mt-4">
            <div className="row">
              <div className="col-md-3 nsingle_sidebar mb-4">
                <ul className="list-inline tab_link mb-1">
                  <li className="list-inline-item mb-2">
                    <a className="p-1">Startups</a>
                  </li>
                  <li className="list-inline-item mb-2">
                    <a className="p-1">Venture</a>
                  </li>
                </ul>
                <div className="author__avatar">
                  <a href="#">
                    <img src={author_avatar} alt="author" />
                  </a>
                </div>
                <h4 className="mt-2">
                  <a href="#">Alex Wilhelm</a> is the Editor in Chief of
                  Hackthon News, covering the intersection of startups and
                  money.
                </h4>
                <div className="border-top border-bottom pt-4 pb-4 mt-5 share-section">
                  <p>
                    <strong>share</strong>
                  </p>
                  <ul className="llist-unstyled list-inline mb-2 d-flex justify-content-left">
                    <li className="mr-2">
                      <a href="#!">
                        <i className="fab fa-linkedin" />
                      </a>
                    </li>
                    <li className="mr-2">
                      <a href="#!">
                        <i className="fab fa-facebook-square" />
                      </a>
                    </li>
                    <li className="mr-2">
                      <a href="#!">
                        <i className="fab fa-twitter-square" />
                      </a>
                    </li>
                    <li className="mr-2">
                      <a href="#!">
                        <i className="fas fa-rss-square" />
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i className="fas fa-envelope" />
                      </a>
                    </li>
                  </ul>
                  <span className="share_counter">5 shares</span>
                </div>
              </div>
              <div className="col-md-9">
                <p>
                  {" "}
                  Twitter reported its Q2 earnings this morning. The company
                  presented a mixed picture of its performance with strong
                  trailing financial results and slack usage metrics.
                </p>
                <p>
                  {" "}
                  In the second quarter, Twitter reported revenue of $711
                  million (up 24 percent), well above expectations of $696.2
                  million. The company also reported $0.17 in adjusted per-share
                  profit, meeting expectations. So one beatand one meet. Not
                  bad.
                </p>
                <p>
                  However, Twitter did not excite the investing className with
                  its forward-looking metrics. First, the company’s financial
                  guidance was light. Per TechCrunch, Twitter expects its
                  adjusted EBITDA to “decline to $215-$235 million in the next
                  quarter.” Twitter reported adjusted EBITDA of $265 million in
                  the second quarter. That’s not great for a company that now
                  partially trades on its ability to generate income instead of
                  merely growth.
                </p>
                <p>
                  Twitter also reported fewer monthly active users in the second
                  quarter than the quarter before. The company reported 335
                  million monthly active users in the second quarter, down one
                  million from 336 million in the first. Twitter’s international
                  usage held steady at 267 million monthly actives, while its
                  U.S. audience slipped from 69 million to 68 million in the
                  second quarter.
                </p>
              </div>
            </div>
          </section>
          <section className="mt-4">
            <div className="row ">
              <div className="col-md-12">
                <div className="back-to-news">
                  <Link className="pr-2" to="/news">
                    back to news
                  </Link>
                </div>
              </div>
            </div>
          </section>
          <NewsFooter />
        </div>
      </main>
    );
  }
}
export default NewsDetails;
