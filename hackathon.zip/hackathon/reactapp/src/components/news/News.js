import React, { Component } from "react";
import NewsBody from "./NewsBody";
import NewsFooter from "./NewFooter";

export default class News extends Component {
  render() {
    return (
      <main className="page-wrapper">
        <div className="container news-container">
          <NewsBody />
          <NewsFooter />
        </div>
      </main>
    );
  }
}
