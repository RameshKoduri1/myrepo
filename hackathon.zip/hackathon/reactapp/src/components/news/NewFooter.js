import React, { Component } from "react";
class NewsFooter extends Component {
  render() {
    return (
      <footer className="footer-news mt-5">
        <div className="row">
          <div className="col-md-6 col-sm-6 ">
            <h5 className="text-uppercase text-sm-left text-center">
              {" "}
              <a className="navbar-brand m-0" href="#">
                Hackthon
              </a>
            </h5>
          </div>
          <div className="col-md-6 col-sm-6">
            <ul className="llist-unstyled list-inline mb-2 d-flex justify-content-center justify-content-sm-end">
              <li className="ml-2">
                <a href="#!">
                  <i className="fab fa-linkedin" />
                </a>
              </li>
              <li className="ml-2">
                <a href="#!">
                  <i className="fab fa-facebook-square" />
                </a>
              </li>
              <li className="ml-2">
                <a href="#!">
                  <i className="fab fa-twitter-square" />
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-6 text-sm-left text-center ">
            © 2018 hackthon, inc. all rights reserved.
          </div>
          <div className="col-sm-6">
            <ul className="list-unstyled list-inline mb-2 d-flex justify-content-center justify-content-sm-end">
              <li className="ml-2">
                <a href="#!">editorial partners: oath tech </a>
              </li>
              <li className="ml-2">
                <a href="#!">privacy policy</a>
              </li>
              <li className="ml-2">
                <a href="#!">terms of service</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    );
  }
}

export default NewsFooter;
