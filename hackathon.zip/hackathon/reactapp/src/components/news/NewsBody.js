import React, { Component } from "react";
import { Link } from "react-router-dom";
import newss_tab from "../../../assets/images/news-banner-top.jpg";
import new_banner from "../../../assets/images/news-banner-top.jpg";
class NewsBody extends Component {
  render() {
    return (
      <div>
        <section>
          <div className="row">
            <div className="col-xl-12">
              <h2 className=" text-center mt-3 mb-3 font-weight-bold">
                Hackthon <a href="#">News</a>
              </h2>
            </div>
            <div className="col-xl-12">
              <a
                href="#"
                className="news-banner d-flex align-items-center"
                style={{ backgroundImage: `url(${new_banner})` }}
              >
                <h1 className="text-center p-4">customer management system</h1>
              </a>
            </div>
          </div>
        </section>
        <section className="news-section mt-4">
          <div className="row">
            <div className="col-md-2 col-sm-3 news_sidebar news-desktop-view">
              <h3>Sections</h3>
              <ul className="list-unstyled">
                <li>
                  <a href="#">Proust</a>
                </li>
                <li>
                  <a href="#">Diversity</a>
                </li>
                <li>
                  <a href="#"> Crypto </a>
                </li>
              </ul>
            </div>
            <div className="col-md-10 col-sm-9">
              <div className="row border-bottom mb-3 pb-3">
                <div className="col-sm-4 news-desktop-view">
                  <a
                    className="news-bg"
                    style={{ backgroundImage: `url(${newss_tab})` }}
                  />
                </div>
                <div className="col-sm-8">
                  <ul className="list-inline tab_link mb-1">
                    <li className="list-inline-item mb-2">
                      <a className="p-1">Startups</a>
                    </li>
                    <li className="list-inline-item mb-2">
                      <a className="p-1">Venture</a>
                    </li>
                  </ul>
                  <h3 className="font-weight-bold">
                    <Link to="/newsDetails">
                      ScaleFactor Raises $10M To Help SMBs Automate Accounting
                      Processes
                    </Link>
                  </h3>
                  <p>
                    Financial operations software platform ScaleFactor has
                    raised $10 million in a Series A, announced today.
                  </p>
                  <div className="d-flex justify-content-between">
                    <div className="news_author">
                      <Link to="/newsDetails">Savannah Dowling</Link>
                    </div>
                    <div className="news_date">July 25, 2018</div>
                  </div>
                </div>
              </div>
              <div className="row border-bottom mb-3 pb-3">
                <div className="col-sm-4 news-desktop-view">
                  <a
                    className="news-bg"
                    style={{ backgroundImage: `url(${newss_tab})` }}
                  />
                </div>
                <div className="col-sm-8">
                  <ul className="list-inline tab_link mb-1">
                    <li className="list-inline-item mb-2">
                      <a className="p-1">Startups</a>
                    </li>
                    <li className="list-inline-item mb-2">
                      <a className="p-1">Venture</a>
                    </li>
                  </ul>
                  <h3 className="font-weight-bold">
                    <Link to="/newsDetails">
                      ScaleFactor Raises $10M To Help SMBs Automate Accounting
                      Processes
                    </Link>
                  </h3>
                  <p>
                    Financial operations software platform ScaleFactor has
                    raised $10 million in a Series A, announced today.
                  </p>
                  <div className="d-flex justify-content-between">
                    <div className="news_author">
                      <Link to="/newsDetails">Savannah Dowling</Link>
                    </div>
                    <div className="news_date">July 25, 2018</div>
                  </div>
                </div>
              </div>
              <div className="row mb-3 pb-3">
                <div className="col-sm-4 news-desktop-view">
                  <a
                    className="news-bg"
                    style={{ backgroundImage: `url(${newss_tab})` }}
                  />
                </div>
                <div className="col-sm-8">
                  <ul className="list-inline tab_link mb-1">
                    <li className="list-inline-item mb-2">
                      <a className="p-1">Startups</a>
                    </li>
                    <li className="list-inline-item mb-2">
                      <a className="p-1">Venture</a>
                    </li>
                  </ul>
                  <h3 className="font-weight-bold">
                    <Link to="/newsDetails">
                      ScaleFactor Raises $10M To Help SMBs Automate Accounting
                      Processes
                    </Link>
                  </h3>
                  <p>
                    Financial operations software platform ScaleFactor has
                    raised $10 million in a Series A, announced today.
                  </p>
                  <div className="d-flex justify-content-between">
                    <div className="news_author">
                      <a href="#">Savannah Dowling</a>
                    </div>
                    <div className="news_date">July 25, 2018</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="text-center mt-4">
          <div className="row ">
            <div className="col-md-12 justify-content-center">
              <nav
                aria-label="Page navigation"
                className="p-2 border-bottom border-top"
              >
                <ul className="pagination mb-0 justify-content-center">
                  <li className="page-item">
                    <a className="page-link" href="#">
                      Previous
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      1
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      2
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      3
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      Next
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </section>
      </div>
    );
  }
}

export default NewsBody;
