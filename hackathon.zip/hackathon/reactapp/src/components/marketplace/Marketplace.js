import React from "react";
import MarketplaceHeader from "../marketplace/MarketplaceHeader";
import MarketplaceBody from "../marketplace/MarketplaceBody";
import Footer from "../Footer";

const Marketplace = props => {
  return (
    <div>
      <main className="page-wrapper">
        <MarketplaceHeader />
        <MarketplaceBody />
      </main>
      <Footer />
    </div>
  );
};

export default Marketplace;
