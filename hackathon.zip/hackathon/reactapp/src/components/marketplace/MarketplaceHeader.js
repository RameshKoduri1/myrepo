import React from "react";

const MarketplaceHeader = props => {
  return (
    <div>
      <section className="text-baner d-flex align-items-center text-light text-center">
        <div className="container ">
          <div className="row">
            <div className="col-xl-12">
              <h1>Hackthon Marketplace</h1>
              <p>
                Add best-in-class data to your hackthon experience—à la carte.{" "}
              </p>
              <button type="button" className="btn btn-raised btn-info">
                How It Works
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
export default MarketplaceHeader;
