import React, { Component } from "react";
import { Link } from "react-router-dom";
import imgCap from "../../../assets/images/img-cap.svg";
import { productList } from "../../actions/product_action";
import { connect } from "react-redux";

class MarketplaceBody extends Component {
  componentWillMount() {
    this.props.productList();
  }

  render() {
    const { products } = this.props;
    return (
      <div>
        <div style={{ backgroundImage: `url(${imgCap})` }} />
        <section className="market-outer pt-5 pb-4">
          <div className="container">
            <div className="row">
              <div className="col-md-3 col-sm-3 col-xs-12 pt-3">
                <h4>Categories</h4>
                <ul className="list-group">
                  <li className="list-group-item active">Free apps</li>
                  <li className="list-group-item">Sales Prospecting</li>
                  <li className="list-group-item">Investor Leads</li>
                  <li className="list-group-item">Market Insights</li>
                  <li className="list-group-item">Competitive Intel</li>
                </ul>
              </div>
              <div className="col-md-9 col-sm-9 col-xs-12">
                <div className="row">
                  <div className="col-md-8 col-sm-8 col-xs-12">
                    <div className="form-group serach-block">
                      <button
                        className="btn bmd-btn-icon"
                        htmlFor="search"
                        data-target="#collapse-search"
                        aria-expanded="false"
                        aria-controls="collapse-search"
                      >
                        <i className="material-icons">search</i>
                      </button>
                      <label htmlFor="search" className="bmd-label-floating">
                        Search Here...
                      </label>
                      <input className="form-control" type="text" id="search" />
                    </div>
                  </div>
                  <div className="col-md-4 col-sm-4 col-xs-12">
                    <div className="form-group">
                      <label
                        htmlFor="exampleSelect1"
                        className="bmd-label-floating"
                      >
                        Sort bys
                      </label>
                      <select className="form-control" id="exampleSelect1">
                        <option>Price(low to high)</option>
                        <option>Price(high to low)</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="row">
                  {products &&
                    products.success &&
                    products.data.map((product, index) => (
                      <div className="col-md-6 col-sm-6 mb-3" key={index}>
                        <Link
                          to={`marketplace/${product.id}`}
                          className="card-outer"
                        >
                          <div className="card">
                            <div
                              className="card-img"
                              style={{
                                backgroundImage: `url(${product.image})`
                              }}
                            />
                            <div className="card-body">
                              <h5 className="card-title">{product.title}</h5>
                              <p className="card-text">{product.description}</p>
                            </div>
                          </div>
                        </Link>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    toast: state.toast,
    products: state.products
  };
}

export default connect(
  mapStateToProps,
  { productList }
)(MarketplaceBody);
