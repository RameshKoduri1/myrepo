import React, { Component } from "react";
import { Link } from "react-router-dom";
import Footer from "../Footer";
import Apptopia_admin_1_1 from "../../../assets/images/Apptopia_admin_1-1.png";
import Apptopia_admin_3_1 from "../../../assets/images/Apptopia_admin_3-1.png";
import Apptopia_Filters from "../../../assets/images/Apptopia_Filters.png";
import Pasted_image from "../../../assets/images/Pasted-image.png";
import { productGet } from "../../actions/product_action";
import { connect } from "react-redux";
class MarketplaceProductDetails extends Component {
  componentWillMount() {
    this.props.productGet(this.props.match.params.id);
  }
  render() {
    const { products } = this.props;
    return (
      <main className="page-wrapper">
        <section className="marketplace-single pt-5 pb-4">
          <div className="container">
            <div className="row">
              <div className="col-sm-12 mb-3">
                <Link to="/marketplace">
                  <i className="fas fa-angle-left" />&nbsp;BACK TO MARKETPLACE
                </Link>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-12 mt-3 mb-3">
                <div className="card p-4 pl-5 pr-5">
                  <div className="row">
                    <div className="col-md-2 mb-4">
                      <img
                        src={products && products.image}
                        className="border"
                        alt="thumbnail"
                      />
                    </div>
                    <div className="col-md-10">
                      <div className="row">
                        <div className="col-md-8 col-lg-10">
                          <h1>{products && products.title}</h1>
                          <p>{products && products.description}</p>
                          <ul className="list-inline tab_link">
                            <li className="list-inline-item mb-2">
                              <a className="border p-1">Free Apps</a>
                            </li>
                            <li className="list-inline-item mb-2">
                              <a className="border p-1">Sales Prospecting</a>
                            </li>
                            <li className="list-inline-item mb-2">
                              <a className="border p-1">Market Insights</a>
                            </li>
                            <li className="list-inline-item mb-2">
                              <a className="border p-1">Competitive Intel</a>
                            </li>
                          </ul>
                          <ul className="list-inline">
                            <li className="list-inline-item mr-3 mb-2">
                              <i className="fas fa-images" />
                              <span>Use with Pro Search</span>
                            </li>
                            <li className="list-inline-item mr-3 mb-2">
                              <i className="fas fa-images" />
                              <span>Allows Exportsh</span>
                            </li>
                            <li className="list-inline-item mb-2">
                              <i className="fas fa-images" />
                              <span>View on Profiles</span>
                            </li>
                          </ul>
                        </div>
                        <div className="col-lg-2 col-md-4 text-center d-flex flex-column justify-content-center">
                          <Link to="/login">
                            <button
                              type="submit"
                              className="btn btn-raised btn-success"
                            >
                              Login to Use
                            </button>
                          </Link>
                          <h3 className="font-weight-bold">Free</h3>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-top mt-2 mb-4" />

                  <div className="row">
                    <div className="col-md-12 mb-4">
                      <div className="carousel-outermrk">
                        <div
                          id="carouselExampleIndicators"
                          className="carousel slide"
                          data-ride="carousel"
                        >
                          <ol className="carousel-indicators">
                            <li
                              data-target="#carouselExampleIndicators"
                              data-slide-to="0"
                            />
                            <li
                              data-target="#carouselExampleIndicators"
                              data-slide-to="1"
                            />
                            <li
                              data-target="#carouselExampleIndicators"
                              data-slide-to="3"
                            />
                          </ol>
                          <div className="carousel-inner" role="listbox">
                            <div className="carousel-item active">
                              <img src={Apptopia_admin_1_1} alt="First_slide" />
                            </div>
                            <div className="carousel-item">
                              <img
                                src={Apptopia_admin_3_1}
                                alt="Second_slide"
                              />
                            </div>
                            <div className="carousel-item">
                              <img src={Apptopia_Filters} alt="third_slide" />
                            </div>
                          </div>
                          <a
                            className="carousel-control-prev"
                            href="#carouselExampleIndicators"
                            role="button"
                            data-slide="prev"
                          >
                            <i className="fas fa-angle-left" />
                          </a>
                          <a
                            className="carousel-control-next"
                            href="#carouselExampleIndicators"
                            role="button"
                            data-slide="next"
                          >
                            <i className="fas fa-angle-right" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-12">
                      <p className="text-center">
                        {" "}
                        <a href="#" className="resources-link">
                          {products && products.name} provides 15 new data
                          fields in Hackthon.
                        </a>
                      </p>
                      <h3 className="mt-5 font-weight-bold"> Overview</h3>
                      <p>
                        {products && products.name} in-depth web traffic and
                        engagement information such as traffic, month-over-month
                        growth, global rankings, page views per visit, and more.
                        By enabling visibility into behavior on websites and
                        mobile apps, SimilarWeb allows customers to use another
                        pool of data alongside their Hackthon experience and get
                        a more comprehensive view of a company’s digital
                        presence.
                      </p>
                      <p className="mt-5">
                        How do customers use {products && products.name} data?
                      </p>
                      <ul>
                        <li>
                          Understand where companies and competitors have
                          growing web traffic as an indicator of which countries
                          the company is growing in and how fast.
                        </li>
                        <li>
                          {" "}
                          Compare performance against industry leaders,
                          competitors, and similar companies, using metrics like
                          MoM web traffic growth, bounce rate, and more.{" "}
                        </li>
                        <li>
                          Grow market share by optimizing your marketing, sales,
                          and growth strategies based off of traffic and
                          engagement stats.
                        </li>
                      </ul>
                      <h3 className="mt-5 font-weight-bold">
                        Hear from {products && products.name} customers
                      </h3>
                      <blockquote className="blockquote mb-0">
                        <p>
                          “{products && products.name} allows us to see exactly
                          where we are in terms of the market. We can analyze
                          our performance against both the industry and specific
                          competitors and instantly identify unknown
                          competitors. This is extremely valuable since it puts
                          our site performance into a wider context.”
                        </p>
                        <footer className="blockquote-footer">
                          Laurence M., Head of Product Effectiveness, The
                          Guardian
                        </footer>
                      </blockquote>
                      <img src={Pasted_image} className="mt-5" alt="pasted" />
                      <h3 className="mt-5 font-weight-bold">Resources</h3>
                      <ul className="list-unstyled resources-list">
                        <li>
                          <a className="resources-link ">
                            How to search with SimilarWeb filters
                          </a>
                        </li>
                        <li>
                          <a className="resources-link ">
                            How to search with SimilarWeb filters
                          </a>
                        </li>
                        <li>
                          <a className="resources-link ">
                            How to search with SimilarWeb filters
                          </a>
                        </li>
                        <li>
                          <a className="resources-link ">
                            How to search with SimilarWeb filters
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <Footer />
      </main>
    );
  }
}

function mapStateToProps(state) {
  return {
    toast: state.toast,
    products: state.products
  };
}

export default connect(
  mapStateToProps,
  { productGet }
)(MarketplaceProductDetails);
