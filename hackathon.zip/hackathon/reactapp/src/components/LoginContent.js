import React, { Component } from "react";
import { connect } from "react-redux";
import { Redirect } from "react-router";
import { authenticate } from "../actions/login_action";
import Toast from "./Toast";
import newToast from "../actions/new_toast";
import { userRegistration } from "../actions/user_action";

class LoginContent extends Component {
  constructor(props) {
    super(props);
    this.props.newToast(null);
    this.state = {
      first_name: "",
      last_name: "",
      password: "",
      password_confirmation: "",
      email: "",
      contactNo: "",
      gender: ""
    };
  }

  handleChange = e => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  onTabChange = e => {
    this.setState({
      first_name: "",
      last_name: "",
      password: "",
      password_confirmation: "",
      email: "",
      contactNo: "",
      gender: ""
    });
    this.props.newToast(null);
  };

  authenticate = e => {
    e.preventDefault();
    this.props.authenticate(this.state);
  };

  userRegistration = e => {
    e.preventDefault();
    this.props.userRegistration(this.state);
  };

  render() {
    const { login } = this.props;
    return login.loggingIn ? (
      <Redirect to="/" />
    ) : (
      <div className="home-inner-wrapper d-flex flex-column">
        <section className="home-text-top p-3 bg-white fixed-top card">
          <h4 className="mb-0 font-weight-normal">Login</h4>
        </section>
        <section className="home-widget-outer">
          <div className="container container-login">
            <div className="row mt-2">
              <div className="col-sm-12 mt-3 mb-3">
                <div className="card">
                  <div className="card-body p-0">
                    <ul className="nav nav-tabs" id="myTab" role="tablist">
                      <li className="nav-item">
                        <a
                          className="nav-link active"
                          id="login-tab"
                          data-toggle="tab"
                          href="#login"
                          role="tab"
                          aria-controls="login"
                          aria-selected="true"
                          onClick={this.onTabChange}
                        >
                          LOGIN
                        </a>
                      </li>
                      <li className="nav-item">
                        <a
                          className="nav-link"
                          id="register-tab"
                          data-toggle="tab"
                          href="#register"
                          role="tab"
                          aria-controls="register"
                          aria-selected="false"
                          onClick={this.onTabChange}
                        >
                          REGISTER
                        </a>
                      </li>
                    </ul>
                    <div className="tab-content" id="myTabContent">
                      <div
                        className="tab-pane fade show active"
                        id="login"
                        role="tabpanel"
                        aria-labelledby="login-tab"
                      >
                        <div className="text-center pt-3">
                          <h4 className="font-weight-normal">
                            {" "}
                            Log in using social authentication
                          </h4>
                          <ul className="list-inline mb-2">
                            <li className="list-inline-item">
                              <a href="#!" className="text-light mr-2">
                                <i className="fab fa-linkedin" />
                              </a>
                            </li>
                            <li className="list-inline-item">
                              <a href="#!" className="text-light  mr-2">
                                <i className="fab fa-facebook-square" />
                              </a>
                            </li>
                            <li className="list-inline-item">
                              <a href="#!" className="text-light  mr-2">
                                <i className="fab fa-twitter-square" />
                              </a>
                            </li>
                          </ul>
                          <div className="center-devider">
                            <span className="font-weight-normal text-secondary">
                              {" "}
                              OR{" "}
                            </span>
                          </div>
                          <h4 className="font-weight-normal">
                            Log in with your e-mail address
                          </h4>
                        </div>
                        <form onSubmit={this.authenticate} className="p-4">
                          {this.props.toast ? (
                            <Toast
                              dismiss={this.handleClearToast}
                              message={this.props.toast}
                            />
                          ) : null}
                          <div className="form-group">
                            <label
                              htmlFor="E-mail"
                              className="bmd-label-floating"
                            >
                              E-mail Address*
                            </label>
                            <input
                              type="email"
                              className="form-control"
                              name="email"
                              onChange={this.handleChange}
                              required
                            />
                          </div>
                          <div className="form-group">
                            <label
                              htmlFor="password"
                              className="bmd-label-floating"
                            >
                              Password*
                            </label>
                            <input
                              type="password"
                              className="form-control"
                              name="password"
                              onChange={this.handleChange}
                              autoComplete="off"
                              required
                            />
                          </div>
                          <div className="d-flex justify-content-between">
                            <button
                              type="button"
                              className="btn btn-light text-black"
                              data-toggle="modal"
                              data-target="#forgotpassword"
                            >
                              Forgot password?
                            </button>
                            <button
                              type="submit"
                              className="btn btn-raised btn-info"
                            >
                              Submit
                            </button>
                          </div>
                        </form>
                      </div>
                      <div
                        className="tab-pane fade"
                        id="register"
                        role="tabpanel"
                        aria-labelledby="register-tab"
                      >
                        <div className="text-center pt-3">
                          <h4 className="font-weight-normal">
                            Register using social authentication
                          </h4>
                          <ul className="list-inline">
                            <li className="list-inline-item">
                              <a href="#!" className="text-light mr-2">
                                <i className="fab fa-linkedin" />
                              </a>
                            </li>
                            <li className="list-inline-item">
                              <a href="#!" className="text-light  mr-2">
                                <i className="fab fa-facebook-square" />
                              </a>
                            </li>
                            <li className="list-inline-item">
                              <a href="#!" className="text-light  mr-2">
                                <i className="fab fa-twitter-square" />
                              </a>
                            </li>
                          </ul>
                          <div className="center-devider">
                            <span className="font-weight-normal text-secondary">
                              {" "}
                              OR{" "}
                            </span>
                          </div>
                          <h4 className="font-weight-normal">
                            {" "}
                            Register using your e-mail address
                          </h4>
                        </div>
                        <form
                          onSubmit={this.userRegistration}
                          className="p-4"
                          autoComplete="off"
                        >
                          {this.props.toast ? (
                            <Toast
                              dismiss={this.handleClearToast}
                              message={this.props.toast}
                            />
                          ) : null}
                          <div className="form-group">
                            <label
                              htmlFor="E-mail"
                              className="bmd-label-floating"
                            >
                              E-mail Address*
                            </label>
                            <input
                              type="email"
                              name="email"
                              className="form-control"
                              id="Email"
                              onChange={this.handleChange}
                              required
                            />
                          </div>
                          <div className="form-group">
                            <label
                              htmlFor="firstname"
                              className="bmd-label-floating"
                            >
                              First Name*
                            </label>
                            <input
                              type="text"
                              name="first_name"
                              className="form-control"
                              id="firstname"
                              onChange={this.handleChange}
                              required
                            />
                          </div>
                          <div className="form-group">
                            <label id="lastname" className="bmd-label-floating">
                              Last Name*
                            </label>
                            <input
                              type="text"
                              name="last_name"
                              className="form-control"
                              id="lastname"
                              onChange={this.handleChange}
                              required
                            />
                          </div>
                          <div className="form-group">
                            <label
                              htmlFor="password"
                              className="bmd-label-floating"
                            >
                              Password*
                            </label>
                            <input
                              type="password"
                              name="password"
                              className="form-control"
                              onChange={this.handleChange}
                              required
                            />
                          </div>
                          <div className="form-group">
                            <label
                              htmlFor="password-confirm"
                              className="bmd-label-floating"
                            >
                              Password (Confirm)*
                            </label>
                            <input
                              type="password"
                              name="password_confirmation"
                              className="form-control"
                              onChange={this.handleChange}
                              required
                            />
                          </div>
                          <div className="form-group">
                            <div>
                              {" "}
                              <label
                                htmlFor="Gender"
                                className="bmd-label-floating"
                              >
                                Gender
                              </label>
                            </div>
                            <div className="custom-control custom-radio custom-control-inline">
                              <input
                                type="radio"
                                id="customRadioInline1"
                                name="gender"
                                value="Male"
                                onChange={this.handleChange}
                                className="custom-control-input"
                              />
                              <label
                                className="custom-control-label"
                                htmlFor="customRadioInline1"
                              >
                                Male
                              </label>
                            </div>
                            <div className="custom-control custom-radio custom-control-inline">
                              <input
                                type="radio"
                                id="customRadioInline2"
                                name="gender"
                                value="Female"
                                onChange={this.handleChange}
                                className="custom-control-input"
                              />
                              <label
                                className="custom-control-label"
                                htmlFor="customRadioInline2"
                              >
                                Female
                              </label>
                            </div>
                          </div>
                          <div className="form-group">
                            <label
                              htmlFor="contactNo"
                              className="bmd-label-floating"
                            >
                              ContactNo
                            </label>
                            <input
                              type="text"
                              name="contactNo"
                              className="form-control"
                              id="contactNo"
                              onChange={this.handleChange}
                              pattern="^[7-9][0-9]{9}$"
                              required
                            />
                          </div>
                          <div className="d-flex flex-row">
                            <button
                              type="submit"
                              className="btn btn-raised btn-info"
                            >
                              Register
                            </button>
                            <span className="small pl-3">
                              By clicking on Register, you agree to
                              <a className="cb-link" target="_blank" href="#">
                                terms &amp; conditions
                              </a>
                              and
                              <a className="cb-link" target="_blank" href="#">
                                privacy policy
                              </a>
                            </span>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    toast: state.toast,
    login: state.login
  };
}

export default connect(
  mapStateToProps,
  { authenticate, userRegistration, newToast }
)(LoginContent);
