import React, { Component } from "react";
import SideBar from "./SideBar";
import LoginContent from "./LoginContent";

class Login extends Component {
  render() {
    return (
      <main className="home-wrapper">
        <SideBar />
        <div className="bmd-layout-backdrop" />
        <LoginContent />
      </main>
    );
  }
}

export default Login;
