import React from 'react';
import navTop from "../../assets/images/nav-top.png"
import {Link} from "react-router-dom"
const SideBar = (props) => {
    return (
        <aside className="home-aside bg-white">
            <a href="#" className="nav-top-image">
                <img src={navTop} alt="nav" />
            </a>
            <nav className="bg-white">
                <ul className="list-inline mt-3 mobile-view">
                    <li className="list-inline-item">
                        <Link className="nav-link" to="/login">Login</Link>
                    </li>
                    <li className="list-inline-item">
                        <a className="nav-link" href="#">Register</a>
                    </li>
                </ul>
                <ul className="list-group bmd-list-group-sm">
                    <li className="list-group-item">
                        <a href="#"><i className="fas fa-building mr-2"></i>Companies</a>
                    </li>
                    <li className="list-group-item">
                        <a href="#"><i className="fas fa-users mr-2"></i> People</a>
                    </li>
                    <li className="list-group-item">
                        <a href="#"><i className="fas fa-donate mr-2"></i> Investors</a>
                    </li>
                    <li className="list-group-item">
                        <a href="#"><i className="fas fa-dollar-sign mr-2"></i> Funding Rounds</a>
                    </li>
                    <li className="list-group-item">
                        <a href="#"><i className="fab fa-deviantart mr-2"></i> Acquisitions</a>
                    </li>
                    <li className="list-group-item">
                        <a href="#"><i className="fas fa-graduation-cap mr-2"></i> School</a>
                    </li>
                    <li className="list-group-item">
                        <a href="#"><i className="fas fa-calendar mr-2"></i> Event</a>
                    </li>
                    <li className="list-group-item">
                        <a href="#"><i className="fas fa-search mr-2"></i> My Search</a>
                    </li>
                </ul>
            </nav>
            <footer className="aside-footer bg-white">
                <ul className="nav justify-content">
                    <li className="nav-item">
                        <a className="nav-link active" href="#!">About</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#!">Terms</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#!">Careers</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#!">Sitemap</a>
                    </li>
                </ul>
                <p className="text-center">© 2018 All rights reserved.</p>
            </footer>
        </aside>
    );
}

export default SideBar;