import React from "react";

const ProductForm = props => {
  return (
    <section className="gform_section pt-5 pb-5">
      <div className="container">
        <div className="row">
          <div className="col-md-12 col-sm-12 ">
            <h2 className="text-center">Contact Us</h2>
            <form className="form_container p-4 mt-5">
              <div className="form-group">
                <label htmlFor="firstname" className="bmd-label-floating">
                  First Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="firstname"
                  required
                />
              </div>
              <div className="form-group">
                <label id="lastname" className="bmd-label-floating">
                  Last Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="lastname"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="CompanyEmail1" className="bmd-label-floating">
                  Company Email
                </label>
                <input
                  type="email"
                  className="form-control"
                  id="CompanyEmail1"
                />
              </div>
              <div className="form-group">
                <label htmlFor="companyName" className="bmd-label-floating">
                  Company
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="company"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="PhoneNumber" className="bmd-label-floating">
                  Phone Number
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="PhoneNumber"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="test" className="bmd-label-floating">
                  Test
                </label>
                <input type="text" className="form-control" id="test" />
              </div>
              <div className="text-center">
                <button type="submit" className="btn btn-raised btn-primary">
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductForm;
