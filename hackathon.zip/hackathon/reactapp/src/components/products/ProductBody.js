import React from "react";
import milkyWay from "../../../assets/images/milky-way.jpg";
import image from "../../../assets/images/image-1.jpg";
import apiImage from "../../../assets/images/api.png";
import cloudImage from "../../../assets/images/cloud.png";
import logos from "../../../assets/images/logos.png";
import growth from "../../../assets/images/growth.png";
import analysis from "../../../assets/images/analysis.png";
const ProductBody = props => {
  var sectionStyle = {
    backgroundImage: `url(${milkyWay})`
  };

  return (
    <div>
      <section className="data-point pt-5 pb-5">
        <div className="container">
          <div className="d-flex flex-md-row flex-column align-items-center">
            <div className="col-md-6 pt-5 pb-5">
              <div className="item">
                <h3>Advanced search</h3>
                <p>
                  Use unlimited filters to find the companies that matter. Save
                  your search & we’ll find new matches while you’re away.
                </p>
              </div>
            </div>
            <div className="col-md-6" data-aos=" fade-left">
              <img src={image} alt="img" />
            </div>
          </div>
          <div className="d-flex flex-md-row-reverse flex-column align-items-center">
            <div className="col-md-6">
              <h3>Charts</h3>
              <p>
                Visually analyze company data right on profile pages, including
                funding, investor activity, and more.
              </p>
            </div>
            <div className="col-md-6">
              <img src={image} alt="img" />
            </div>
          </div>
          <div className="d-flex flex-md-row flex-column align-items-center">
            <div className="col-md-6 pt-5 pb-5">
              <h3>Alerts</h3>
              <p>
                Get custom alerts for the companies in your saved searches and
                lists to stay updated in real-time.
              </p>
            </div>
            <div className="col-md-6">
              <img src={image} alt="img" />
            </div>
          </div>
        </div>
      </section>
      <section className="waypoint pt-5 pb-5">
        <div className="container">
          <div className="row">
            <div className="col-md-12 col-xs-12">
              <h2 className="text-center">About Our Service</h2>
            </div>
            <div className="waypont-container col-md-12 col-xs-12">
              <div className="row pt-5">
                <div className="col-md-3 col-sm-6 col-xs-12 mb-4">
                  <img src={apiImage} alt="img" />
                  <div className="p-3">API</div>
                </div>
                <div className="col-md-3 col-sm-6 col-xs-12 mb-4">
                  <img src={cloudImage} alt="img" />
                  <div className="p-3">Cloud</div>
                </div>
                <div className="col-md-3 col-sm-6 col-xs-12 mb-4">
                  <img src={growth} alt="img" />
                  <div className="p-3">Grouth</div>
                </div>
                <div className="col-md-3 col-sm-6 col-xs-12 mb-4">
                  <img src={analysis} alt="img" />
                  <div className="p-3">Analysis</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="showcase pt-5 pb-5" style={sectionStyle}>
        <div className="container">
          <div className="row">
            <div className="col-md-12 col-sm-12">
              <h2 className="text-center">Hear from our customers</h2>
              <div
                id="myCarousel"
                className="carousel slide"
                data-ride="carousel"
              >
                {/*  Carousel indicators */}
                <div className="container">
                  <ol className="carousel-indicators">
                    <li
                      data-target="#myCarousel"
                      data-slide-to="0"
                      className="active"
                    />
                    <li data-target="#myCarousel" data-slide-to="1" />
                  </ol>
                  {/*  Wrapper for carousel items */}
                  <div className="carousel-inner mb-4">
                    <div className="item carousel-item active">
                      <p className="testimonial">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Nam eu sem tempor, varius quam at, luctus dui. Mauris
                        magna metus, dapibus nec turpis vel, semper malesuada
                        ante. Idac bibendum scelerisque non non purus.
                        Suspendisse varius nibh non aliquet.
                      </p>
                      <p className="overview text-right">
                        <b>Paula Wilson</b>, Media Analyst
                      </p>
                    </div>
                    <div className="item carousel-item">
                      <p className="testimonial">
                        Vestibulum quis quam ut magna consequat faucibus.
                        Pellentesque eget nisi a mi suscipit tincidunt. Utmtc
                        tempus dictum risus. Pellentesque viverra sagittis quam
                        at mattis. Suspendisse potenti. Aliquam sit amet gravida
                        nibh, facilisis gravida odio.
                      </p>
                      <p className="overview text-right">
                        <b>Antonio Moreno</b>, Web Developer
                      </p>
                    </div>
                  </div>
                  <div className="text-center">
                    <button type="button" className="btn btn-raised btn-info">
                      SEE CASE STUDY
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="brand-logo">
        <div className="container">
          <div className="row">
            <div className="col-md-12 col-sm-12 pt-3 pb-3 text-center">
              <img src={logos} alt="logo" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProductBody;
