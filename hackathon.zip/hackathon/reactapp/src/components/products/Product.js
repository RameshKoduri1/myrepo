import React from 'react';
import ProductHeader from './ProductHeader';
import ProductBody from './ProductBody';
import ProductForm from './ProductForm';
import Footer from '../Footer';

const Product = (props) => {
    return (
        <main className="page-wrapper">
            <ProductHeader />
            <ProductBody />
            <ProductForm />
            <Footer />
        </main>
    );
}

export default Product;