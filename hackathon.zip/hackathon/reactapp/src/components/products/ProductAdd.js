import React, { Component } from "react";
import { connect } from "react-redux";
import {
  productAdd,
  productList,
  productDelete
} from "../../actions/product_action";
import Toast from "../Toast";
import newToast from "../../actions/new_toast";

class ProductAdd extends Component {
  componentWillMount() {
    this.props.productList();
  }
  constructor(props) {
    super(props);
    this.state = {
      id: "",
      title: "",
      name: "",
      description: "",
      organization: "",
      image: "",
      release_date: ""
    };
  }

  handleChange = e => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.productAdd(this.state, () => {
      this.props.productList();
    });
  };

  onFormChange = () => {
    this.setState({
      id: "",
      title: "",
      name: "",
      description: "",
      organization: "",
      image: "",
      release_date: ""
    });
    this.props.newToast(null);
  };

  formatDate = date => {
    var now = new Date(date);
    var y = now.getFullYear();
    var m = now.getMonth() + 1;
    var d = now.getDate();
    var mm = m < 10 ? "0" + m : m;
    var dd = d < 10 ? "0" + d : d;
    return "" + y + "-" + mm + "-" + dd;
  };

  handleUpdate = product => {
    this.setState({
      id: product.id,
      title: product.title,
      name: product.name,
      description: product.description,
      organization: product.organization,
      image: product.image,
      release_date: this.formatDate(product.release_date)
    });
    this.props.newToast(null);
  };

  handleRemove = id => {
    this.props.productDelete(id, () => {
      this.props.productList();
    });
  };

  render() {
    const { products } = this.props;
    return (
      <div>
        <main className="page-wrapper">
          <section className="marketplace-single pt-3 pb-3">
            <div className="container-fluid">
              <div className="card">
                <div className="card-header d-flex justify-content-between">
                  <div>
                    <h3 className="mb-sm-0 font-weight-bold">Featured</h3>
                  </div>
                  <div>
                    <button
                      type="button"
                      className="btn btn-raised btn-info m-0"
                      data-toggle="modal"
                      data-target="#addfile"
                      onClick={this.onFormChange}
                    >
                      Add
                    </button>
                  </div>
                </div>
                <div className="table-responsive">
                  <table className="table admin-table table-bordered m-0 table-striped table-hover">
                    <thead className="thead-dark">
                      <tr>
                        <th scope="col">ID</th>
                        <th scope="col">TITLE</th>
                        <th scope="col">NAME</th>
                        <th scope="col">DESCRIPTION</th>
                        <th scope="col">ORGANIZATION</th>
                        <th scope="col">IMAGE</th>
                        <th scope="col">RELEASE DATE</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products &&
                        products.success &&
                        products.data.map((product, index) => (
                          <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{product.title}</td>
                            <td>{product.name}</td>
                            <td>{product.description}</td>
                            <td>{product.organization}</td>
                            <td>{product.image}</td>
                            <td>{product.release_date}</td>
                            <td className="text-center">
                              <div className="btn-group m-0">
                                <button
                                  type="button"
                                  className="btn btn-primary bmd-btn-icon dropdown-toggle"
                                  data-toggle="dropdown"
                                  aria-haspopup="true"
                                  aria-expanded="false"
                                >
                                  <i className="material-icons">more_vert</i>
                                </button>
                                <div className="dropdown-menu dropdown-menu-right p-0">
                                  <button
                                    className="dropdown-item"
                                    data-toggle="modal"
                                    data-target="#addfile"
                                    onClick={() => {
                                      this.handleUpdate(product);
                                    }}
                                  >
                                    Edit
                                  </button>
                                  <button
                                    className="dropdown-item"
                                    onClick={() => {
                                      this.handleRemove(product.id);
                                    }}
                                  >
                                    Delete
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
                <div className="card-footer">
                  <nav aria-label="Page navigation example">
                    <ul className="pagination justify-content-end m-0">
                      <li className="page-item mr-3">
                        <div className="input-group">
                          <span className="d-flex flex-column justify-content-center pr-2">
                            Page No.
                          </span>
                          <select className="custom-select">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                          </select>
                          <div className="input-group-append">
                            <button
                              className="btn btn-raised btn-info m-0"
                              type="button"
                            >
                              GO
                            </button>
                          </div>
                        </div>
                      </li>
                      <li className="page-item">
                        <a
                          className="page-link h-100 border m-0"
                          href="#"
                          aria-label="Previous"
                        >
                          <span aria-hidden="true">&laquo;</span>
                          <span className="sr-only">Previous</span>
                        </a>
                      </li>
                      <li className="page-item">
                        <a
                          className="page-link h-100 border "
                          href="#"
                          aria-label="Next"
                        >
                          <span aria-hidden="true">&raquo;</span>
                          <span className="sr-only">Next</span>
                        </a>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </section>
        </main>
        <div
          className="modal bd-example-modal-lg"
          id="addfile"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="exampleModalVerticalLabel"
          aria-hidden="true"
        >
          <div
            className="modal-dialog modal-dialog-centered modal-lg"
            role="document"
          >
            <form onSubmit={this.handleSubmit} className="w-100">
              <div className="modal-content">
                <div className="modal-header bg-info p-2 pl-3 pr-3">
                  <h4 className="modal-title" id="forgotpassword">
                    Add Product
                  </h4>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>{" "}
                  </button>
                </div>
                <div className="modal-body">
                  {this.props.toast ? (
                    <Toast
                      dismiss={this.handleClearToast}
                      message={this.props.toast}
                    />
                  ) : null}
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <label htmlFor="title" className="bmd-label-floating">
                        Title
                      </label>
                      <input
                        type="text"
                        name="title"
                        className="form-control"
                        id="title"
                        onChange={this.handleChange}
                        value={this.state.title}
                        required
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label htmlFor="name" className="bmd-label-floating">
                        Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        className="form-control"
                        id="name"
                        onChange={this.handleChange}
                        value={this.state.name}
                        required
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label htmlFor="description" className="bmd-label-floating">
                      Description
                    </label>
                    <input
                      type="text"
                      name="description"
                      className="form-control"
                      id="description"
                      onChange={this.handleChange}
                      value={this.state.description}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label
                      htmlFor="Organization"
                      className="bmd-label-floating"
                    >
                      Organization
                    </label>
                    <input
                      type="text"
                      name="organization"
                      className="form-control"
                      id="Organization"
                      onChange={this.handleChange}
                      value={this.state.organization}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="image" className="bmd-label-floating">
                      Image
                    </label>
                    <input
                      type="text"
                      name="image"
                      className="form-control"
                      id="image"
                      onChange={this.handleChange}
                      value={this.state.image}
                      required
                    />
                  </div>
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <label
                        htmlFor="releaseDate"
                        className="bmd-label-floating"
                      >
                        Release Date
                      </label>
                      <input
                        type="text"
                        pattern="^([12]\d{3}[-](0?[1-9]|1[0-2])[-](0[1-9]|[12]\d|3[01]))$"
                        name="release_date"
                        className="form-control"
                        id="releaseDate"
                        placeholder="YYYY-MM-DD"
                        onChange={this.handleChange}
                        value={this.state.release_date}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="modal-footer p-2 pl-3 pr-3 border-top">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                  <button
                    type="reset"
                    className="btn btn btn-info"
                    onClick={() => {
                      this.onFormChange();
                    }}
                  >
                    Reset
                  </button>
                  <button type="submit" className="btn btn btn-info">
                    Save
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    toast: state.toast,
    products: state.products
  };
}
export default connect(
  mapStateToProps,
  { productList, productAdd, productDelete, newToast }
)(ProductAdd);
