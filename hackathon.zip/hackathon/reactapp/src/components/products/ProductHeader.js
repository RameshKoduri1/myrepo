import React from "react";
const ProductHeader = props => {
  return (
    <section className="text-baner d-flex align-items-center text-light">
      <div className="container product-container">
        <div className="row">
          <div className="col-xl-12">
            <h1>Hackthon Pro</h1>
            <p>Find, track, and analyze the companies you care about.</p>
            <button type="button" className="btn btn-raised btn-info">
              GET STARTED
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductHeader;
