import React, { Component } from "react";
import { connect } from "react-redux";
import Toast from "../Toast";
import newToast from "../../actions/new_toast";
import { userList, userAdd, userDelete } from "../../actions/user_action";
class User extends Component {
  componentWillMount() {
    this.props.userList();
  }
  constructor(props) {
    super(props);
    this.state = {
      id: "",
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      contactNo: "",
      gender: "",
      image: null
    };
  }

  handleChange = e => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.userAdd(this.state, () => {
      this.props.userList();
    });
  };

  onFormChange = e => {
    this.setState({
      id: "",
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      contactNo: "",
      gender: ""
    });
    this.props.newToast(null);
  };

  handleUpdate = user => {
    this.setState({
      id: user.id,
      first_name: user.first_name,
      last_name: user.last_name,
      email: user.email,
      contactNo: user.contactNo,
      gender: user.gender
    });
    this.props.newToast(null);
  };

  handleRemove = id => {
    this.props.userDelete(id, () => {
      this.props.userList();
    });
  };

  render() {
    const { users } = this.props;
    return (
      <div>
        <main className="page-wrapper">
          <section className="marketplace-single pt-3 pb-3">
            <div className="container-fluid">
              <div className="card">
                <div className="card-header d-flex justify-content-between">
                  <div>
                    <h3 className="mb-sm-0 font-weight-bold">Featured</h3>
                  </div>
                  <div>
                    <button
                      type="button"
                      className="btn btn-raised btn-info m-0"
                      data-toggle="modal"
                      data-target="#addfile"
                      onClick={this.onFormChange}
                    >
                      Add
                    </button>
                  </div>
                </div>
                <div className="table-responsive">
                  <table className="table admin-table table-bordered m-0 table-striped table-hover">
                    <thead className="thead-dark">
                      <tr>
                        <th scope="col">ID</th>
                        <th scope="col">FIRST_NAME</th>
                        <th scope="col">LAST_NAME</th>
                        <th scope="col">EMAIL</th>
                        <th scope="col">CONTACT_NO</th>
                        <th scope="col">GENDER</th>
                        <th scope="col">IMAGE</th>
                        <th scope="col">ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users &&
                        users.success &&
                        users.data.map((user, index) => (
                          <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{user.first_name}</td>
                            <td>{user.last_name}</td>
                            <td>{user.email}</td>
                            <td>{user.contactNo}</td>
                            <td>{user.gender}</td>
                            <td>{user.image}</td>
                            <td className="text-center">
                              <div className="btn-group m-0">
                                <button
                                  type="button"
                                  className="btn btn-primary bmd-btn-icon dropdown-toggle"
                                  data-toggle="dropdown"
                                  aria-haspopup="true"
                                  aria-expanded="false"
                                >
                                  <i className="material-icons">more_vert</i>
                                </button>
                                <div className="dropdown-menu dropdown-menu-right">
                                  <button
                                    className="dropdown-item"
                                    data-toggle="modal"
                                    data-target="#addfile"
                                    onClick={() => {
                                      this.handleUpdate(user);
                                    }}
                                  >
                                    Edit
                                  </button>
                                  <button
                                    className="dropdown-item"
                                    onClick={() => {
                                      this.handleRemove(user.id);
                                    }}
                                  >
                                    Delete
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
                <div className="card-footer">
                  <nav aria-label="Page navigation example">
                    <ul className="pagination justify-content-end m-0">
                      <li className="page-item mr-3">
                        <div className="input-group">
                          <span className="d-flex flex-column justify-content-center pr-2">
                            Page No.
                          </span>
                          <select className="custom-select">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                          </select>
                          <div className="input-group-append">
                            <button
                              className="btn btn-raised btn-info m-0"
                              type="button"
                            >
                              GO
                            </button>
                          </div>
                        </div>
                      </li>
                      <li className="page-item">
                        <a
                          className="page-link h-100 border m-0"
                          href="#"
                          aria-label="Previous"
                        >
                          <span aria-hidden="true">&laquo;</span>
                          <span className="sr-only">Previous</span>
                        </a>
                      </li>
                      <li className="page-item">
                        <a
                          className="page-link h-100 border "
                          href="#"
                          aria-label="Next"
                        >
                          <span aria-hidden="true">&raquo;</span>
                          <span className="sr-only">Next</span>
                        </a>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </section>
        </main>
        {/*  modal  Add Videos and Others  */}
        <div
          className="modal bd-example-modal-lg"
          id="addfile"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="exampleModalVerticalLabel"
          aria-hidden="true"
        >
          <div
            className="modal-dialog modal-dialog-centered modal-lg"
            role="document"
          >
            <form onSubmit={this.handleSubmit} className="w-100">
              <div className="modal-content">
                <div className="modal-header bg-info p-2 pl-3 pr-3">
                  <h4 className="modal-first_name" id="forgotpassword">
                    Add user
                  </h4>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>{" "}
                  </button>
                </div>
                <div className="modal-body">
                  {this.props.toast ? (
                    <Toast
                      dismiss={this.handleClearToast}
                      message={this.props.toast}
                    />
                  ) : null}
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <label
                        htmlFor="first_name"
                        className="bmd-label-floating"
                      >
                        First Name
                      </label>
                      <input
                        type="text"
                        name="first_name"
                        className="form-control"
                        id="first_name"
                        onChange={this.handleChange}
                        value={this.state.first_name}
                        required
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label htmlFor="last_name" className="bmd-label-floating">
                        Last Name
                      </label>
                      <input
                        type="text"
                        name="last_name"
                        className="form-control"
                        id="last_name"
                        onChange={this.handleChange}
                        value={this.state.last_name}
                        required
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label htmlFor="email" className="bmd-label-floating">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      className="form-control"
                      id="email"
                      onChange={this.handleChange}
                      value={this.state.email}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <div>
                      {" "}
                      <label htmlFor="Gender" className="bmd-label-floating">
                        Gender
                      </label>
                    </div>
                    <div className="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        id="customRadioInline1"
                        name="gender"
                        value="Male"
                        onChange={this.handleChange}
                        className="custom-control-input"
                      />
                      <label
                        className="custom-control-label"
                        htmlFor="customRadioInline1"
                      >
                        Male
                      </label>
                    </div>
                    <div className="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        id="customRadioInline2"
                        name="gender"
                        value="Female"
                        onChange={this.handleChange}
                        className="custom-control-input"
                      />
                      <label
                        className="custom-control-label"
                        htmlFor="customRadioInline2"
                      >
                        Female
                      </label>
                    </div>
                  </div>
                  <div className="form-group">
                    <label htmlFor="contactNo" className="bmd-label-floating">
                      ContactNo
                    </label>
                    <input
                      type="tel"
                      name="contactNo"
                      className="form-control"
                      id="contactNo"
                      onChange={this.handleChange}
                      value={this.state.contactNo}
                      pattern="^[7-9][0-9]{9}$"
                      required
                    />
                  </div>
                  <div className="form-group">
                    {/* <label htmlFor="password" className="bmd-label-floating">
                      Password
                    </label> */}
                    <input
                      hidden
                      type="password"
                      name="password"
                      className="form-control"
                      id="password"
                      onChange={this.handleChange}
                      // value={this.state.password}
                      required
                    />
                  </div>
                </div>
                <div className="modal-footer p-2 pl-3 pr-3 border-top">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                  <button
                    type="reset"
                    className="btn btn btn-info"
                    onClick={() => {
                      this.onFormChange();
                    }}
                  >
                    Reset
                  </button>
                  <button type="submit" className="btn btn btn-info">
                    Save
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    toast: state.toast,
    users: state.user
  };
}
export default connect(
  mapStateToProps,
  { userList, userAdd, userDelete, newToast }
)(User);
