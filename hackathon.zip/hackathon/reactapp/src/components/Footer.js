import React from "react";

const Footer = props => {
  return (
    <footer>
      <div className="container">
        <div className="row">
          <div className="col-md-12 col-sm-12 mt-4 mb-4">
            <a className="navbar-brand text-light" href="#">
              Hackthon
            </a>
          </div>
          <div className="col-md-3 col-sm-6 ">
            <h5 className="text-uppercase text-info">Stay Connected </h5>
            <p>  Hackthon News</p>
            <p>Subscribe to the   Hackthon Daily</p>
            <ul className="list-unstyled d-flex flex-row">
              <li>
                <a href="#!" className="text-light mr-2">
                  <i className="fab fa-facebook-square" />
                </a>
              </li>
              <li>
                <a href="#!" className="text-light  mr-2">
                  <i className="fab fa-twitter-square" />
                </a>
              </li>
              <li>
                <a href="#!" className="text-light  mr-2">
                  <i className="fab fa-instagram" />
                </a>
              </li>
            </ul>
          </div>
          <div className="col-md-3 col-sm-6 ">
            <h5 className="text-uppercase text-info">Who We Are</h5>
            <ul className="list-unstyled ">
              <li>
                <a href="#!" className="text-light">
                  Company
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                  Career
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                  Partners
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                  Blog
                </a>
              </li>
            </ul>
          </div>
          <div className="col-md-3 col-sm-6 ">
            <h5 className="text-uppercase text-info">What We Do</h5>
            <ul className="list-unstyled">
              <li>
                <a href="#!" className="text-light">
                  hackthon Pro
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                  Marketplace
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                    Hackthon Enterprise
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                    Hackthon for Applications
                </a>
              </li>
            </ul>
          </div>
          <div className="col-md-3 col-sm-6 ">
            <h5 className="text-uppercase text-info">Popular Links</h5>
            <ul className="list-unstyled">
              <li>
                <a href="#!" className="text-light">
                  Featured Lists and Searches
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                  The   Hackthon Difference
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                  Knowledge Center
                </a>
              </li>
              <li>
                <a href="#!" className="text-light">
                  Create a Profile
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="border border-info border-right-0 border-left-0">
        <div className="container">
          <div className="row">
            <div className="col-md-12 col-sm-12">
              <ul className="nav justify-content-center">
                <li className="nav-item">
                  <a className="nav-link text-light" href="#!">
                    Browse By: Organizations, People, Events
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link text-light" href="#!">
                    Terms of Service | Privacy Policy
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link text-light" href="#!">
                    © 2018   Hackthon Inc. All Rights Reserved.
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
export default Footer;
