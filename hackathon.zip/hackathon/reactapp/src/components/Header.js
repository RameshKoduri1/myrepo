import React, { Component } from "react";
import { Link } from "react-router-dom";
import newToast from "../actions/new_toast";
import { connect } from "react-redux";
import { logOutUser } from "../actions/login_action";

const LoggedOutView = props => {
  return (
    <header className="fixed-top home-page">
      <nav className="navbar navbar-expand-lg navbar-dark bg-info ">
        <button className="navbar-toggler sidbar-toggle" type="button">
          <span className="sr-only">Toggle drawer</span>
          <i className="material-icons">menu</i>
        </button>
        <Link className="navbar-brand" to="/">
          Hackthon
        </Link>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <Link className="nav-link" to="/product">
                Products
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/marketplace">
                Marketplace
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/news">
                News
              </Link>
            </li>
          </ul>
          <div className="bmd-form-group bmd-collapse-inline pull-xs-right">
            <span id="collapse-search" className="collapse text-light">
              <input
                className="form-control"
                type="text"
                id="search"
                placeholder="Enter your query..."
              />
            </span>
            <button
              className="btn bmd-btn-icon"
              htmlFor="search"
              data-toggle="collapse"
              data-target="#collapse-search"
              aria-expanded="false"
              aria-controls="collapse-search"
            >
              <i className="material-icons text-light">search</i>
            </button>
            <ul className="navbar-nav desktop-view">
              <li className="nav-item ">
                <Link
                  className="nav-link"
                  to="/login"
                  onClick={() => {
                    props.handleToast();
                  }}
                >
                  Login
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
};

const LoggedInView = props => {
  return (
    <header>
      <nav className="navbar navbar-expand-lg navbar-dark bg-info ">
        {/* <button className="navbar-toggler sidbar-toggle" type="button">
            <span className="sr-only">Toggle drawer</span>
            <i className="material-icons">menu</i>
          </button> */}

        <Link className="navbar-brand" to="/">
          Hackthon
        </Link>
        <button
          className="navbar-toggler btn btn-outline-primary ml-auto "
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <Link className="nav-link" to="/product">
                Products
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/marketplace">
                Marketplace
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/news">
                News
              </Link>
            </li>
            <li className="nav-item dropdown">
              <a
                className="nav-link dropdown-toggle"
                href="#"
                id="navbarDropdown"
                role="button"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
              >
                Admin
              </a>
              <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                <Link className="dropdown-item" to="/productAdd">
                  Product
                </Link>
                <Link className="dropdown-item" to="/user">
                  User
                </Link>
              </div>
            </li>
          </ul>
          <div className="bmd-form-group bmd-collapse-inline">
            <span id="collapse-search" className="collapse text-light">
              <input
                className="form-control"
                type="text"
                id="search"
                placeholder="Enter your query..."
              />
            </span>
            <button
              className="btn bmd-btn-icon"
              htmlFor="search"
              data-toggle="collapse"
              data-target="#collapse-search"
              aria-expanded="false"
              aria-controls="collapse-search"
            >
              <i className="material-icons text-light">search</i>
            </button>
          </div>
          <ul className="navbar-nav">
            <li className="nav-item ">
              <Link className="nav-link" to="/login" onClick={props.logout}>
                Logout
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  );
};

class Header extends Component {
  handleToast = e => {
    this.props.newToast(null);
  };
  logout = () => {
    this.props.logOutUser();
    this.props.newToast(null);
    window.location.reload(1);
  };
  render() {
    let user = JSON.parse(localStorage.getItem("user"));

    return user ? (
      <LoggedInView logout={this.logout} />
    ) : (
      <LoggedOutView handleToast={this.handleToast} />
    );
  }
}

function mapStateToProps(state) {
  return {
    toast: state.toast
  };
}

export default connect(
  mapStateToProps,
  { newToast, logOutUser }
)(Header);
