import React from "react";

const Toast = props => {
  if (props.message.success) {
    return (
      <div
        className="alert alert-success alert-dismissible fade show"
        role="alert"
      >
        {props.message.msg}
      </div>
    );
  } else {
    return (
      <div
        className="alert alert-warning alert-dismissible fade show"
        role="alert"
      >
        {props.message.msg}
      </div>
    );
  }
};

export default Toast;
