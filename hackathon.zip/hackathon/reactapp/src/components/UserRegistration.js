import React from 'react';
import SideBar from './SideBar';
import LoginContent from './LoginContent';

const UserRegistration = (props) => {
    return (
        <div>
            <main className="home-wrapper">
                <SideBar />
                <div className="bmd-layout-backdrop"></div>
                <LoginContent />
            </main>
        </div>
    );
}

export default UserRegistration;