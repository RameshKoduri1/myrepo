import React, { Component } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Header from "./Header";
import Login from "./Login";
import UserRegistration from "./UserRegistration";
import Marketplace from "./marketplace/Marketplace";
import Product from "./products/Product";
import Home from "./home/Home";
import ProductAdd from "./products/ProductAdd";
import User from "./user/User";
import News from "./news/News";
import MarketplaceProductDetails from "./marketplace/MarketplaceProductDetails";
import NewsDetails from "./news/NewDetails";

class App extends Component {
  render() {
    return (
      <div>
        <Router>
          <div>
            <Header />
            <Switch>
              <Route exact path="/" component={Home} />
              <Route exact path="/product" component={Product} />
              <Route exact path="/productAdd" component={ProductAdd} />
              <Route exact path="/marketplace" component={Marketplace} />
              <Route
                exact
                path="/marketplace/:id"
                component={MarketplaceProductDetails}
              />
              <Route exact path="/login" component={Login} />
              <Route exact path="/registration" component={UserRegistration} />
              <Route exact path="/user" component={User} />
              <Route exact path="/news" component={News} />
              <Route exact path="/newsDetails" component={NewsDetails} />
            </Switch>
          </div>
        </Router>
      </div>
    );
  }
}

export default App;
