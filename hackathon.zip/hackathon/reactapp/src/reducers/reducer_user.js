import {
  USER_REGISTRATION,
  USER_LIST,
  USER_ADD,
  USER_DELETE,
  USER_UPDATE
} from "../actions/types";

export default function(state = null, action) {
  switch (action.type) {
    case USER_REGISTRATION:
      return action.payload;

    case USER_LIST:
      return action.payload;

    case USER_ADD:
      return action.payload;

    case USER_UPDATE:
      return action.payload;

    case USER_DELETE:
      return action.payload;

    default:
      return state;
  }
}
