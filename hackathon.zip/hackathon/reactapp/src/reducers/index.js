import { combineReducers } from "redux";
import ToastReducer from "./reducer_toast";
import login from "./reducer_login";
import user from "./reducer_user";
import products from "./reducer_product";

const rootReducer = combineReducers({
  toast: ToastReducer,
  login: login,
  user: user,
  products: products
});

export default rootReducer;
