import {
  PRODUCT_ADD,
  PRODUCT_LIST,
  PRODUCT_UPDATE,
  PRODUCT_DELETE,
  PRODUCT_GET
} from "../actions/types";

export default function(state = null, action) {
  switch (action.type) {
    case PRODUCT_LIST:
      return action.payload;

    case PRODUCT_ADD:
      return action.payload;

    case PRODUCT_DELETE:
      return action.payload;

    case PRODUCT_GET:
      return action.payload;

    case PRODUCT_UPDATE:
      return action.payload;

    default:
      return state;
  }
}
