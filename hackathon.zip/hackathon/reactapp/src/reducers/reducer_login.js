import { USER_AUTHENTICATE, USER_LOGOUT } from "../actions/types";

let user = JSON.parse(localStorage.getItem("user"));

const initialState = user ? { loggedIn: true, user } : {};

export default function(state = initialState, action) {
  switch (action.type) {
    case USER_AUTHENTICATE:
      return {
        loggingIn: true,
        user: action.payload
      };
    case USER_LOGOUT:
      return {};

    default:
      return state;
  }
}
