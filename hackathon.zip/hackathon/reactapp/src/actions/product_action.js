import {
  PRODUCT_ADD,
  PRODUCT_UPDATE,
  PRODUCT_DELETE,
  PRODUCT_LIST,
  PRODUCT_GET
} from "./types";
import newToast from "./new_toast";
import axios from "axios";

const ROOT_URL = `http://${process.env.REACT_APP_API_HOST}/products`;

export const addProductAsync = product => {
  return {
    type: PRODUCT_ADD,
    payload: product
  };
};

export const updateProductAsync = product => {
  return {
    type: PRODUCT_UPDATE,
    payload: product
  };
};

export const productAdd = (product, callback) => {
  var message = { success: false, msg: null };
  if (!product.id) {
    return dispatch => {
      axios({
        method: "post",
        url: `${ROOT_URL}`,
        data: product
      })
        .then(res => {
          message.success = res.data.success;
          message.msg = res.data.message;

          if (res.data.success) {
            dispatch(addProductAsync(product));
            dispatch(newToast(message));
          } else {
            dispatch(newToast(message));
          }
        })
        .then(() => callback());
    };
  } else {
    return dispatch => {
      axios({
        method: "put",
        url: `${ROOT_URL}/${product.id}`,
        data: product
      })
        .then(res => {
          message.success = res.data.success;
          message.msg = res.data.message;

          if (res.data.success) {
            dispatch(updateProductAsync(product));
            dispatch(newToast(message));
          } else {
            dispatch(newToast(message));
          }
        })
        .then(() => callback());
    };
  }
};

export const listProductAsync = product => {
  return {
    type: PRODUCT_LIST,
    payload: product
  };
};

export const productList = product => {
  var message = { success: false, msg: null };
  return dispatch => {
    axios({
      method: "get",
      url: `${ROOT_URL}`,
      data: product
    }).then(res => {
      message.success = res.data.success;
      message.msg = res.data.message;

      if (res.data.success) {
        dispatch(listProductAsync(res.data));
      } else {
        dispatch(newToast(message));
      }
    });
  };
};

export const getProductAsync = product => {
  return {
    type: PRODUCT_GET,
    payload: product
  };
};

export const productGet = productId => {
  var message = { success: false, msg: null };
  return dispatch => {
    axios({
      method: "get",
      url: `${ROOT_URL}/${productId}`
    }).then(res => {
      message.success = res.data.success;
      message.msg = res.data.message;

      if (res.data.success) {
        dispatch(getProductAsync(res.data.data));
      } else {
        dispatch(newToast(message));
      }
    });
  };
};

export const deleteProductAsync = product => {
  return {
    type: PRODUCT_DELETE,
    payload: product
  };
};

export const productDelete = (productId, callback) => {
  var message = { success: false, msg: null };
  return dispatch => {
    axios({
      method: "delete",
      url: `${ROOT_URL}/${productId}`
    })
      .then(res => {
        message.success = res.data.success;
        message.msg = res.data.message;

        if (res.data.success) {
          dispatch(deleteProductAsync(res.data.data));
          dispatch(newToast(message));
        } else {
          dispatch(newToast(message));
        }
      })
      .then(() => callback());
  };
};
