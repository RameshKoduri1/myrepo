import {
  USER_REGISTRATION,
  USER_LIST,
  USER_ADD,
  USER_DELETE,
  USER_UPDATE
} from "./types";
import newToast from "./new_toast";
import axios from "axios";

const ROOT_URL = `http://${process.env.REACT_APP_API_HOST}/users`;

export const userRegistrationAsync = user => {
  return {
    type: USER_REGISTRATION,
    payload: user
  };
};

export const userRegistration = user => {
  var message = { success: false, msg: null };
  return dispatch => {
    axios({
      method: "post",
      url: `${ROOT_URL}`,
      data: user
    }).then(res => {
      message.success = res.data.success;
      message.msg = res.data.message;

      if (res.data.success) {
        dispatch(userRegistrationAsync(user));
        dispatch(newToast(message));
      } else {
        dispatch(newToast(message));
      }
    });
  };
};

export const addUserAsync = user => {
  return {
    type: USER_ADD,
    payload: user
  };
};

export const updateUserAsync = user => {
  return {
    type: USER_UPDATE,
    payload: user
  };
};

export const userAdd = (user, callback) => {
  var message = { success: false, msg: null };
  if (!user.id) {
    return dispatch => {
      axios({
        method: "post",
        url: `${ROOT_URL}`,
        data: user
      })
        .then(res => {
          message.success = res.data.success;
          message.msg = res.data.message;

          if (res.data.success) {
            dispatch(addUserAsync(user));
            dispatch(newToast(message));
          } else {
            dispatch(newToast(message));
          }
        })
        .then(() => callback());
    };
  } else {
    return dispatch => {
      axios({
        method: "put",
        url: `${ROOT_URL}/${user.id}`,
        data: user
      })
        .then(res => {
          message.success = res.data.success;
          message.msg = res.data.message;

          if (res.data.success) {
            dispatch(updateUserAsync(user));
            dispatch(newToast(message));
          } else {
            dispatch(newToast(message));
          }
        })
        .then(() => callback());
    };
  }
};

export const listUserAsync = user => {
  return {
    type: USER_LIST,
    payload: user
  };
};

export const userList = user => {
  var message = { success: false, msg: null };
  return dispatch => {
    axios({
      method: "get",
      url: `${ROOT_URL}`,
      data: user
    }).then(res => {
      message.success = res.data.success;
      message.msg = res.data.message;

      if (res.data.success) {
        dispatch(listUserAsync(res.data));
      } else {
        dispatch(newToast(message));
      }
    });
  };
};

export const deleteUserAsync = user => {
  return {
    type: USER_DELETE,
    payload: user
  };
};

export const userDelete = (userId, callback) => {
  var message = { success: false, msg: null };
  return dispatch => {
    axios({
      method: "delete",
      url: `${ROOT_URL}/${userId}`
    })
      .then(res => {
        message.success = res.data.success;
        message.msg = res.data.message;

        if (res.data.success) {
          dispatch(deleteUserAsync(res.data.data));
          dispatch(newToast(message));
        } else {
          dispatch(newToast(message));
        }
      })
      .then(() => callback());
  };
};
