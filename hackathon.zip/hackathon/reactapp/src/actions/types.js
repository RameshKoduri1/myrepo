export const NEW_TOAST = "new_toast";
export const CLEAR_TOAST = "clear_toast";

export const USER_AUTHENTICATE = "user_authenticate";
export const USER_LOGOUT = "user_logout";
export const USER_REGISTRATION = "user_registration";
export const USER_LIST = "user_list";
export const USER_ADD = "user_add";
export const USER_UPDATE = "user_update";
export const USER_DELETE = "user_delete";

export const PRODUCT_LIST = "product_list";
export const PRODUCT_GET = "product_get";
export const PRODUCT_ADD = "product_add";
export const PRODUCT_UPDATE = "product_update";
export const PRODUCT_DELETE = "product_delete";
