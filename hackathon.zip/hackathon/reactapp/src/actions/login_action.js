import { USER_AUTHENTICATE, USER_LOGOUT } from "./types";
import newToast from "./new_toast";
import axios from "axios";

const ROOT_URL = `http://${process.env.REACT_APP_API_HOST}/authenticate`;

export const userAuthenticationAsync = user => {
  return {
    type: USER_AUTHENTICATE,
    payload: user
  };
};

export const authenticate = user => {
  var message = { success: false, msg: null };
  return dispatch => {
    axios({
      method: "post",
      url: `${ROOT_URL}`,
      data: user
    }).then(res => {
      message.success = res.data.success;
      message.msg = res.data.message;
      if (res.data.success) {
        dispatch(userAuthenticationAsync(user));
        localStorage.setItem("user", JSON.stringify(user));
        dispatch(newToast(message));
      } else {
        dispatch(newToast(message));
      }
    });
  };
};

export const logOutUser = () => {
  localStorage.removeItem("user");
  return {
    type: USER_LOGOUT
  };
};
