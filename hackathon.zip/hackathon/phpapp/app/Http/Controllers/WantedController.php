<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WantedController extends Controller
{
    //
}
