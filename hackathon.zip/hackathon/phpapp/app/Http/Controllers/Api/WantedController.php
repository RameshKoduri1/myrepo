<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Wanted;
use App\RealWorld\Transformers\WantedTransformer;

class WantedController extends ApiController
{
	/**
     * WantedController constructor.
     *
     * @param WantedTransformer $transformer
     */
    public function __construct(WantedTransformer $transformer)
    {
        $this->transformer = $transformer;
    }

    /**
     * Get all the persons in wanted list.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(){
    	$wanted = Wanted::orderBy('id')->get();
        return $this->respondWithTransformer($wanted);
    }

    public function addPerson(Request $request){
    	$wantedList = new Wanted;

    	$wantedList->name = $request->name;
    	$wantedList->image = $request->image;
    	$wantedList->reason = $request->reason;
    	$wantedList->reward = $request->reward;

    	$wantedList->save();

    	return ["status" => "success"];
    }

    public function updatePerson(Request $request){
    	$result = Wanted::where('name', $request->name)->update(['reason' => $request->reason]);
    	if($result)
    		return ["status" => "success"];
    	else
    		return ["status" => "fail"];
    }

    public function deletePerson(Request $request){
    	$result = Wanted::where('name', $request->name)->delete();
    	if($result)
    		return ["status" => "success"];
    	else
    		return ["status" => "fail"];
    }
}
