<?php

namespace App\RealWorld\Transformers;

class WantedTransformer extends Transformer
{
    protected $resourceName = 'data';

    public function transform($data)
    {
        return [
            'name'     => $data['name'],
            'image'     => $data['image'],
            'reason'  => $data['reason'],
            'reward'       => $data['reward'],
        ];
    }
}