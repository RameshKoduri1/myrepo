<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wanted extends Model
{
	/**
     * The property that defines table name
     *
     * @var string
     */
	protected $table = 'wanted';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name','image','reason','reward'
    ];
}
