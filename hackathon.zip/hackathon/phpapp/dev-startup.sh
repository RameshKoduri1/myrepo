composer install

php artisan key:generate

php artisan jwt:generate

php artisan migrate

php artisan migrate:refresh

php artisan db:seed

php artisan serve --host=0.0.0.0 --port=$ENV_RUN_PORT