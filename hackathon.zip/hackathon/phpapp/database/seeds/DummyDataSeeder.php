<?php

use Illuminate\Database\Seeder;

class DummyDataSeeder extends Seeder
{
    /**
     * Total number of persons in wanted list.
     *
     * @var int
     */
    protected $totalWantedPersons = 3;

    /**
     * Populate the database with dummy data for testing.
     * Complete dummy data generation including relationships.
     * Set the property values as required before running database seeder.
     *
     * @param \Faker\Generator $faker
     */
    public function run(\Faker\Generator $faker)
    {
        $wnatedList = factory(\App\Wanted::class)->times($this->totalWantedPersons)->create();
    }
}
