class CreateWantedLists < ActiveRecord::Migration[5.1]
  def change
    create_table :wanted_lists do |t|
      t.string :name
      t.string :image
      t.string :reason
      t.decimal :reward

      t.timestamps
    end
  end
end
