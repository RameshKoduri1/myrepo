class CreateUsers < ActiveRecord::Migration[5.1]
	def change
		create_table :users do |t|
			t.string :first_name
			t.string :last_name
			t.string :login_id
			t.string :password_digest
			t.string :email
			t.string :contactNo
			t.string :gender
			t.string :image
			t.timestamps
		end
	end
end
