    # user=User.find_or_create_by!(first_name:"Admin", last_name:"Admin",
    # email:"admin@insigniac.com",
    # password_digest: "",
    # contactNo:"1234567890",
    # gender:"M",
    # image:"http://icons.iconarchive.com/icons/paomedia/small-n-flat/256/user-male-icon.png")
    # user.save!


    product=Product.find_or_create_by!(title:"AWS X-RAY",  name:"AWS X-Ray",
    description:"AWS X-Ray helps developers analyze and debug production, distributed applications, such as those built using a microservices architecture.",
    organization:"Amazon Web Service",
    image:"https://wallpaper.wiki/wp-content/uploads/2017/05/wallpaper.wiki-Plain-Wallpapers-HD-Download-Free-PIC-WPE007978.jpg",
    release_date:"10-10-2018")
    product.save!
    
    user = User.find_or_initialize_by(email: "admin@insigniac.com")
    user.contactNo="1234567890"
    user.password = "pass1234"
    user.first_name="admin"
    user.last_name="admin"
    user.password_confirmation = "pass1234"
    user.gender="M"
    user.image="http://icons.iconarchive.com/icons/paomedia/small-n-flat/256/user-male-icon.png"
    user.save!