class AuthKey < ApplicationRecord
 #key
end
