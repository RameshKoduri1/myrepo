class Product < ApplicationRecord
end
