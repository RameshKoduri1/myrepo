class AuthenticationController < ApplicationController
  
  def authenticate
    @user = User.find_by(email: params[:email])
    print @user
    if @user && @user.authenticate(params[:password])
      response = { success: true, message: "You have logged in successfully." }
    else
      response = { success: false, message: "Invalid Login / Password!" }
    end
    json_response(response)
  end
    
end
