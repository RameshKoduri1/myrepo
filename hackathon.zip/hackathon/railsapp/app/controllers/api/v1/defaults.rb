module API
  module V1
    module Defaults
      extend ActiveSupport::Concern

      included do
        # common Grape settings
        version 'v1', using: :path
        format :json
        default_format :json
        # Other Things to Include
        #include Grape::Kaminari

        # global handler for simple not found case
        rescue_from ActiveRecord::RecordNotFound do |e|
          error_response(message: e.message, status: 404)
        end

        # global exception handler, used for error notifications
        rescue_from :all do |e|
          raise e if Rails.env.development? || Rails.env.test?
          # @env is rack data
          req = Rack::Request.new(@env)
          # Raven.capture_exception(e) # TODO: Add back
          Rails.logger.info "API Exception (#{e}) for request: #{req.request_method} #{req.url} #{req.params} ... Details #{([e.message]+e.backtrace).join($/)}"
          error_response(message: 'Internal server error', status: 500)
        end

        # http_basic do |username|
        #   Rails.logger.info "HTTP Basic Auth username: #{username}"
        #   AuthKey.find_by(key: username)
        # end
      end
    end
  end
end
