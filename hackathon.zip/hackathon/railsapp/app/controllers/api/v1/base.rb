module API
  module V1
    class Base < Grape::API
      end
  end
end
