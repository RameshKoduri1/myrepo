module API
  module V1
    module Authenticated
      extend ActiveSupport::Concern

      before do
        header "Access-Control-Allow-Origin", "*"
       end

    #   included do
    #     # HTTP header based authentication
    #     before do
    #       error!(MISSING_AUTH_TOKEN_ERROR, 401) unless headers['Auth-Token']
    #       @user = User.find_by(auth_token: headers['Auth-Token'])
    #       error!(BAD_AUTH_TOKEN_ERROR, 401) unless @user
    #     end
    #   end
    end
  end
end
