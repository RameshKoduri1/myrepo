module API
  class Dispatch < Grape::API
    mount API::V1::Base
  end

  Hackathon = Rack::Builder.new do
    # use API::Logger
    run API::Dispatch
  end
end
