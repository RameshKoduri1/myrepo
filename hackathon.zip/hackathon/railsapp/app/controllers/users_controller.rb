class UsersController < ApplicationController

  def index
    @users = User.all
    response = {success: true, message: "All Products...", data: @users }
    json_response(response)
  end

  def new
    @user = User.new
  end
  
  def show
    @user = User.find(params[:id])
    render json: @user.to_json
  end

  def edit
    @user = User.find(params[:id])
    render json: @user.to_json
  end

  def create
    @user = User.new(user_params)
    if @user.save
      response = {success: true, message: "User has been saved successfully.", data: @user }
    else
      response = {success: false, message: "Email is Already exists!", data: @user }
    end
    json_response(response)

  end
  
  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      response = {success: true, message: "User has been saved successfully.", data: @user }
    else
      response = {success: false, message: "Something went to wrong!", data: @user }
    end
    json_response(response)
  end


  def destroy
    @user = User.find(params[:id])
    if @user.destroy
      response = {success: true, message: "User has been deleted successfully.", data: @user }
    else
      response = {success: false, message: "Something went to wrong!", data: @user }
    end
    json_response(response)
  end

  private
  def user_params
    params.permit(
      :email,
      :password,
      :password_confirmation,
      :first_name,
      :last_name,
      :contactNo,
      :gender,
      :image
      )
  end
end