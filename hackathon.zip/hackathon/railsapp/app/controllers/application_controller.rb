class ApplicationController < ActionController::Base
  include Response
end
