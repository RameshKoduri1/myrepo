class ProductsController < ApplicationController
  before_action :set_product, only: [:show, :edit, :update, :destroy]

  # GET /products
  # GET /products.json
  def index
    @products = Product.all
    response = {success: true, message: "All Products...", data: @products }
    json_response(response)
  end

  # GET /products/1
  # GET /products/1.json
  def show
    @product = Product.find(params[:id])
    response = {success: true, message: "Get Product...", data: @product }
    json_response(response)
  end

  # GET /products/new
  def new
    @product = Product.new
  end

  # GET /products/1/edit
  def edit
  end

  # POST /products
  # POST /products.json
  def create
    @product = Product.new(product_params)
      if @product.save
      response = {success: true, message: "Product has been saved successfully.", data: @product }
      else
        response = {success: false, message: "Something went to wrong!", data: @product }
      end
      json_response(response)
  end

  # PATCH/PUT /products/1
  # PATCH/PUT /products/1.json
  def update
    @product = Product.find(params[:id])
      if @product.update(product_params)
        response = {success: true, message: "Product has been saved successfully.", data: @product }
      else
        response = {success: false, message: "Something went to wrong!", data: @product }
      end
      json_response(response)
  end

  # DELETE /products/1
  # DELETE /products/1.json
  def destroy
    @product=Product.find(params[:id])
    if @product.destroy
      response = {success: true, message: "Product has been deleted successfully.", data: @product }
    else
      response = {success: false, message: "Something went to wrong!", data: @product }
    end
    json_response(response)
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_product
      @product = Product.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def product_params
      params.require(:product).permit(:title, :name, :description, :organization, :image, :release_date)
    end
end
