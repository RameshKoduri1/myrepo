#!/bin/sh

set +e

echo "############################## working #####################"
# If database exists, migrate. Otherweise create and seed
bundle exec rake db:drop
bundle exec rake db:migrate 2>/dev/null || bundle exec rake db:setup
echo "Database Migrations Done!"

rm -rf tmp/pids/*

bundle exec puma -C config/puma.rb

while true; do sleep 30; done;