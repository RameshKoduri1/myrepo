echo "install package"

curl -o- -L https://yarnpkg.com/install.sh | bash

echo "go to work directory"   

cd $APPLICATION

echo "Make executable startup file"  

chmod u+x dev-startup.sh

yarn install