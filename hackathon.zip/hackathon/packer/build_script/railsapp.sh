echo "install package"

apk add --update --no-cache \
    build-base \
    postgresql-dev \
    git \
    imagemagick \
    nodejs-current \
    yarn \
    tzdata \
    file 

echo "go to work directory"   

cd $APPLICATION

echo "Make executable startup file"  

chmod u+x dev-startup.sh

echo " install bundler && run bundle install"

gem install bundler && bundle install --jobs 20 --retry 5    

echo "make assets precompile"
bundle exec rake assets:precompile