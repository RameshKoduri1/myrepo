# Docker Cheatsheet

## How to setup your development environment


```
cp .env.example .env
docker-compose up -d elasticsearch redis memcached db
docker-compose up --build app
```

## No space left on device error

https://forums.docker.com/t/no-space-left-on-device-error/10894

rm -rf ~/Library/Containers/com.docker.docker/Data/com.docker.driver.amd64-linux/Docker.qcow2


## Volumes ##

volumes:
      - /tmp/rails5apistarter/postgresql:/var/lib/postgresql/data

      ^ 1st field is absolute path on your mac: 2nd path is what 1st path is mapped to on the container

## Docker Compose

###  Builds all your images and starts them

```
docker-compose up --build
```

### Start all containers

```
docker-compose start
```

### Start a specific container

```
docker-compose start app
```

### Stop all containers

```
docker-compose down
```

### Restart a specific container

```
docker-compose restart redis
```

### DANGEROUS. DESTRUCTIVE. Will stop all containers and delete all docker images from machine.

```
docker-compose down --rmi all -v --remove-orphans 
```

### Stop all containers

```
docker kill $(docker ps -q)
```

### Remove all containers

```
docker rm $(docker ps -a -q)
```

### Remove all docker images

```
docker rmi -f $(docker images -q)
```

### SSH into docker container

```
docker exec -it dockerrails_app_1 bash
```

### Docker compose development cycle

```
docker-compose build
docker-compose up app
docker-compose run app rake db:create
docker-compose run app rake db:migrate

docker-compose run app rake searchkick:reindex CLASS=Post
```

### Run commands on running docker containers

```
docker exec -it stackrunnerbackend_app_1 echo "hello world"

docker exec -it stackrunnerbackend_app_1 bundle exec rake assets:precompile --trace

docker exec -it stackrunnerbackend_app_1 bundle exec rails tmp:clear assets:clobber

docker exec -it stackrunnerbackend_app_1 bundle exec rake db:migrate

docker exec -it stackrunnerbackend_app_1 bundle install

docker exec -it stackrunnerbackend_app_1 bundle exec rails generate model srec2 instance_name:string 
```

### Run only some docker compose containers in the background

```
docker-compose up -d redis memcached elasticache postgres
```

### Clean build of docker image

```
docker-compose build --no-cache app
```

### Only run app container docker compose

```
docker-compose up --build app
```


## Docker Resources - Must Read

https://blog.codeship.com/running-rails-development-environment-docker/

