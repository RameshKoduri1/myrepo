<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="/" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel 5.5 with React 16 Boilerplate')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(mix('css/light-bootstrap-dashboard.css')); ?>" rel="stylesheet">
    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>
<body>
<div id="root">

    <?php echo $__env->yieldContent('content'); ?>
</div>

<!-- Scripts -->
<!-- 

<script src="<?php echo e(mix('/js/app.js')); ?>"></script> -->
<script src="<?php echo e(mix('/js/manifest.js')); ?>"></script>
<script src="<?php echo e(mix('/js/vendor.js')); ?>"></script>
<script src="<?php echo e(mix('/js/app.js')); ?>"></script>
</body>
</html>
