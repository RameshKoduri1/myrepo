
echo "install package"

apt-get update -y && apt-get install -y openssl zip unzip git wget  


apt-get install -y gnupg

apt-get install -y zlib1g-dev git 


curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
docker-php-ext-install pdo mbstring zip
# install nodejs


curl -sL https://deb.nodesource.com/setup_8.x | bash
apt-get install nodejs -y 

command -v node
command -v npm

# install nginx 

apt-get install nginx -y

command -v nginx 
update-rc.d nginx defaults


cd $APPLICATION
echo "Make executable startup file"
chmod u+x dev-startup.sh
echo " composer install packages"
composer install

php artisan key:generate
npm install 
npm run dev